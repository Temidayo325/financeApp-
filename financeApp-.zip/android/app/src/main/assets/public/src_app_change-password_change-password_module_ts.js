"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_change-password_change-password_module_ts"],{

/***/ 2807:
/*!*******************************************************************!*\
  !*** ./src/app/change-password/change-password-routing.module.ts ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ChangePasswordPageRoutingModule": () => (/* binding */ ChangePasswordPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 8806);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 4001);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 3252);
/* harmony import */ var _change_password_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./change-password.page */ 1226);




const routes = [
    {
        path: '',
        component: _change_password_page__WEBPACK_IMPORTED_MODULE_0__.ChangePasswordPage
    }
];
let ChangePasswordPageRoutingModule = class ChangePasswordPageRoutingModule {
};
ChangePasswordPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], ChangePasswordPageRoutingModule);



/***/ }),

/***/ 6466:
/*!***********************************************************!*\
  !*** ./src/app/change-password/change-password.module.ts ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ChangePasswordPageModule": () => (/* binding */ ChangePasswordPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 8806);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 4001);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 8267);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 8346);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 8099);
/* harmony import */ var _change_password_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./change-password-routing.module */ 2807);
/* harmony import */ var _change_password_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./change-password.page */ 1226);







let ChangePasswordPageModule = class ChangePasswordPageModule {
};
ChangePasswordPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _change_password_routing_module__WEBPACK_IMPORTED_MODULE_0__.ChangePasswordPageRoutingModule
        ],
        declarations: [_change_password_page__WEBPACK_IMPORTED_MODULE_1__.ChangePasswordPage]
    })
], ChangePasswordPageModule);



/***/ }),

/***/ 1226:
/*!*********************************************************!*\
  !*** ./src/app/change-password/change-password.page.ts ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ChangePasswordPage": () => (/* binding */ ChangePasswordPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 8806);
/* harmony import */ var _C_wamp64_www_financeApp_node_modules_ngtools_webpack_src_loaders_direct_resource_js_change_password_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !./node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./change-password.page.html */ 8160);
/* harmony import */ var _change_password_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./change-password.page.scss */ 7841);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 4001);




let ChangePasswordPage = class ChangePasswordPage {
    constructor() { }
    ngOnInit() {
    }
};
ChangePasswordPage.ctorParameters = () => [];
ChangePasswordPage = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Component)({
        selector: 'app-change-password',
        template: _C_wamp64_www_financeApp_node_modules_ngtools_webpack_src_loaders_direct_resource_js_change_password_page_html__WEBPACK_IMPORTED_MODULE_0__["default"],
        styles: [_change_password_page_scss__WEBPACK_IMPORTED_MODULE_1__]
    })
], ChangePasswordPage);



/***/ }),

/***/ 8160:
/*!**************************************************************************************************************************!*\
  !*** ./node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./src/app/change-password/change-password.page.html ***!
  \**************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-app>\r\n     <ion-header class=\"header ion-no-border\">\r\n           <ion-text>\r\n                <ion-button (click)=\"back()\" fill=\"clear\">\r\n                     <ion-icon slot=\"icon-only\" name=\"arrow-back\"></ion-icon>\r\n                     <span class=\"\">Back</span>\r\n               </ion-button>\r\n           </ion-text>\r\n     </ion-header>\r\n     <ion-content>\r\n          <div class=\"content\">\r\n               <div>\r\n                    <ion-text>\r\n                         <h1>Change Password</h1>\r\n                    </ion-text>\r\n                    <ion-text class=\"text\">Your new password must be different from previous used passwords</ion-text>\r\n                    <ion-item lines=\"none\" class=\"border\">\r\n                         <ion-label position=\"stacked\">Password</ion-label>\r\n                         <ion-input [(ngModel)]=\"password\" type=\"password\"></ion-input>\r\n                    </ion-item>\r\n                    <ion-item lines=\"none\" class=\"border\">\r\n                         <ion-label position=\"stacked\">Confirm Password</ion-label>\r\n                         <ion-input [(ngModel)]=\"email\" type=\"password\"></ion-input>\r\n                    </ion-item>\r\n                    <div class=\"flex\">\r\n                         <ion-button size=\"default\" color=\"primary\" (click)=\"requestCode()\">Reset Password</ion-button>\r\n                    </div>\r\n               </div>\r\n          </div>\r\n     </ion-content>\r\n\r\n</ion-app>\r\n");

/***/ }),

/***/ 7841:
/*!***********************************************************!*\
  !*** ./src/app/change-password/change-password.page.scss ***!
  \***********************************************************/
/***/ ((module) => {

module.exports = ".header {\n  padding: 10px 0;\n}\n\nspan {\n  margin-left: 8px;\n}\n\n.content {\n  padding: 10px 15px;\n  letter-spacing: 1px;\n}\n\n.flex {\n  display: flex;\n  justify-content: center;\n}\n\nh1 {\n  line-height: 40px;\n}\n\n.border {\n  border: solid 2px white;\n  border-radius: 20px;\n  margin: 30px;\n}\n\n.text {\n  margin: 15px 0;\n  line-height: 20px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImNoYW5nZS1wYXNzd29yZC5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFFSyxlQUFBO0FBQUw7O0FBRUE7RUFFSyxnQkFBQTtBQUFMOztBQUVBO0VBRUssa0JBQUE7RUFDQSxtQkFBQTtBQUFMOztBQUVBO0VBRUssYUFBQTtFQUNBLHVCQUFBO0FBQUw7O0FBRUE7RUFFSyxpQkFBQTtBQUFMOztBQUVBO0VBRUssdUJBQUE7RUFDQSxtQkFBQTtFQUNBLFlBQUE7QUFBTDs7QUFFQTtFQUVLLGNBQUE7RUFDQSxpQkFBQTtBQUFMIiwiZmlsZSI6ImNoYW5nZS1wYXNzd29yZC5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuaGVhZGVyXHJcbntcclxuICAgICBwYWRkaW5nOiAxMHB4IDA7XHJcbn1cclxuc3BhblxyXG57XHJcbiAgICAgbWFyZ2luLWxlZnQ6IDhweDtcclxufVxyXG4uY29udGVudFxyXG57XHJcbiAgICAgcGFkZGluZzogMTBweCAxNXB4O1xyXG4gICAgIGxldHRlci1zcGFjaW5nOiAxcHg7XHJcbn1cclxuLmZsZXhcclxue1xyXG4gICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbn1cclxuaDFcclxue1xyXG4gICAgIGxpbmUtaGVpZ2h0OiA0MHB4O1xyXG59XHJcbi5ib3JkZXJcclxue1xyXG4gICAgIGJvcmRlcjogc29saWQgMnB4IHdoaXRlIDtcclxuICAgICBib3JkZXItcmFkaXVzOiAyMHB4O1xyXG4gICAgIG1hcmdpbjogMzBweDtcclxufVxyXG4udGV4dFxyXG57XHJcbiAgICAgbWFyZ2luOiAxNXB4IDA7XHJcbiAgICAgbGluZS1oZWlnaHQ6IDIwcHg7XHJcbn1cclxuIl19 */";

/***/ })

}]);
//# sourceMappingURL=src_app_change-password_change-password_module_ts.js.map