"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_tab2_tab2_module_ts"],{

/***/ 9561:
/*!*********************************************!*\
  !*** ./src/app/tab2/tab2-routing.module.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Tab2PageRoutingModule": () => (/* binding */ Tab2PageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 8806);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 4001);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 3252);
/* harmony import */ var _tab2_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./tab2.page */ 4787);




const routes = [
    {
        path: '',
        component: _tab2_page__WEBPACK_IMPORTED_MODULE_0__.Tab2Page,
    }
];
let Tab2PageRoutingModule = class Tab2PageRoutingModule {
};
Tab2PageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule]
    })
], Tab2PageRoutingModule);



/***/ }),

/***/ 4250:
/*!*************************************!*\
  !*** ./src/app/tab2/tab2.module.ts ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Tab2PageModule": () => (/* binding */ Tab2PageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 8806);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ 8099);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 4001);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/common */ 8267);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/forms */ 8346);
/* harmony import */ var _tab2_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./tab2.page */ 4787);
/* harmony import */ var _explore_container_explore_container_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../explore-container/explore-container.module */ 456);
/* harmony import */ var _tab2_routing_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./tab2-routing.module */ 9561);








let Tab2PageModule = class Tab2PageModule {
};
Tab2PageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.NgModule)({
        imports: [
            _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.IonicModule,
            _angular_common__WEBPACK_IMPORTED_MODULE_6__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_7__.FormsModule,
            _explore_container_explore_container_module__WEBPACK_IMPORTED_MODULE_1__.ExploreContainerComponentModule,
            _tab2_routing_module__WEBPACK_IMPORTED_MODULE_2__.Tab2PageRoutingModule
        ],
        declarations: [_tab2_page__WEBPACK_IMPORTED_MODULE_0__.Tab2Page]
    })
], Tab2PageModule);



/***/ }),

/***/ 4787:
/*!***********************************!*\
  !*** ./src/app/tab2/tab2.page.ts ***!
  \***********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Tab2Page": () => (/* binding */ Tab2Page)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 8806);
/* harmony import */ var _C_wamp64_www_financeApp_node_modules_ngtools_webpack_src_loaders_direct_resource_js_tab2_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !./node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./tab2.page.html */ 2040);
/* harmony import */ var _tab2_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./tab2.page.scss */ 282);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 4001);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ 3252);
/* harmony import */ var _Service_expense_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../Service/expense.service */ 4709);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ 8099);





// import { PersonService } from '../Service/person.service';


let Tab2Page = class Tab2Page {
    constructor(router, 
    // private person: PersonService,
    expense, toastCtrl, loadingctrl) {
        this.router = router;
        this.expense = expense;
        this.toastCtrl = toastCtrl;
        this.loadingctrl = loadingctrl;
        this.total = "00.00";
    }
    ionViewWillEnter() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(this, void 0, void 0, function* () {
            yield this.presentLoading("Retrieving your expense....");
            const userData = JSON.parse(localStorage.getItem("user"));
            this.expense.getUserExpense(userData.user_id, localStorage.getItem("token")).subscribe(response => {
                let parsed = (typeof response == 'object') ? response : JSON.parse(response);
                console.log(parsed);
                if (parsed.status == 0) {
                    this.loadingctrl.dismiss();
                    this.presentToast(parsed.message);
                    console.log(parsed);
                }
                else if (parsed.status == 1) {
                    this.loadingctrl.dismiss();
                    this.expenses = parsed.data;
                    this.total = parsed.total;
                    console.log(parsed);
                }
                else {
                    this.loadingctrl.dismiss();
                    this.presentToast("Unable to retrieve current Expenses");
                    console.log(parsed);
                }
            }, (error) => {
                console.log(error);
            });
        });
    }
    presentLoading(message) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(this, void 0, void 0, function* () {
            const loading = yield this.loadingctrl.create({
                cssClass: 'my-custom-class',
                message: message,
                spinner: "lines-sharp",
                backdropDismiss: true,
                id: 'loader'
            });
            yield loading.present();
        });
    }
    presentToast(message, time = 4000, type = "dark") {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(this, void 0, void 0, function* () {
            const toast = yield this.toastCtrl.create({
                message: message,
                position: "bottom",
                color: type,
                duration: time
            });
            toast.present();
        });
    }
    addExpense() {
        this.router.navigate(['/create-expense']);
    }
};
Tab2Page.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__.Router },
    { type: _Service_expense_service__WEBPACK_IMPORTED_MODULE_2__.ExpenseService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.ToastController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.LoadingController }
];
Tab2Page = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_6__.Component)({
        selector: 'app-tab2',
        template: _C_wamp64_www_financeApp_node_modules_ngtools_webpack_src_loaders_direct_resource_js_tab2_page_html__WEBPACK_IMPORTED_MODULE_0__["default"],
        styles: [_tab2_page_scss__WEBPACK_IMPORTED_MODULE_1__]
    })
], Tab2Page);



/***/ }),

/***/ 2040:
/*!****************************************************************************************************!*\
  !*** ./node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./src/app/tab2/tab2.page.html ***!
  \****************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-app>\r\n  <ion-fab slot=\"fixed\" vertical=\"top\" horizontal=\"end\">\r\n    <ion-fab-button color=\"light\" (click)=\"addExpense()\"\r\n      ><ion-icon name=\"add-outline\"></ion-icon\r\n    ></ion-fab-button>\r\n  </ion-fab>\r\n  <ion-header\r\n    color=\"\"\r\n    class=\"header ion-no-border\"\r\n    style=\"clip-path: ellipse(117% 100% at 52.01% 0%)\"\r\n  >\r\n    <div class=\"header-container\">\r\n      <ion-text><h5>Expense</h5></ion-text>\r\n      <ion-text class=\"bolder\"><h1>#{{total}}</h1></ion-text>\r\n    </div>\r\n  </ion-header>\r\n  <ion-content fullscreen=\"true\">\r\n    <div *ngIf=\"total !== 0\">\r\n      <ion-item color=\"primary\" *ngFor=\"let expense of expenses\">\r\n        <div class=\"fullDiv\">\r\n          <div class=\"flex\">\r\n            <ion-text class=\"\">Category: {{expense.category}}</ion-text>\r\n          </div>\r\n          <div class=\"center\">\r\n            <ion-text color=\"tertiary\"\r\n              ><h1 class=\"bold\">#{{expense.amount}}</h1></ion-text\r\n            >\r\n            <ion-text class=\"\">{{expense.created_at}}</ion-text>\r\n          </div>\r\n          <div class=\"flex\">\r\n            <ion-text class=\"\">Description: </ion-text>\r\n            <ion-text class=\"\">{{expense.description}}</ion-text>\r\n          </div>\r\n        </div>\r\n      </ion-item>\r\n    </div>\r\n    <div *ngIf=\"total == 0\" class=\"no-expenses-wrapper\">\r\n      <div class=\"no-expenses\">\r\n        <ion-text>\r\n          <p>\r\n            You have not recorded any expenses yet. Click the button below to\r\n            record an expense\r\n          </p>\r\n        </ion-text>\r\n        <ion-button\r\n          size=\"default\"\r\n          expand=\"block\"\r\n          color=\"tertiary\"\r\n          (click)=\"addExpense()\"\r\n          >Add Expense</ion-button\r\n        >\r\n      </div>\r\n    </div>\r\n  </ion-content>\r\n</ion-app>\r\n");

/***/ }),

/***/ 282:
/*!*************************************!*\
  !*** ./src/app/tab2/tab2.page.scss ***!
  \*************************************/
/***/ ((module) => {

module.exports = ".header {\n  display: grid;\n  justify-content: center;\n  align-items: center;\n  background: #004481;\n  width: 100vw;\n  height: 15vh;\n}\n\n.header-container {\n  text-align: center;\n}\n\n.bolder {\n  font-size: 4em;\n  color: white;\n  font-weight: bolder;\n  text-shadow: 0.5px 0.5px 1px #000;\n  line-height: 70px;\n  margin-top: 0px;\n  letter-spacing: 1px;\n}\n\nh5 {\n  font-size: 1em;\n  color: white;\n}\n\n.bold {\n  font-size: 1.7em;\n  font-weight: bolder;\n  text-shadow: 0.5px 0.5px 1px #000;\n  margin-top: 0px;\n  letter-spacing: 1px;\n  color: white;\n}\n\nion-item {\n  margin: 30px auto;\n  width: 90vw;\n  padding: 15px 0;\n  --border-radius: 10px ;\n}\n\nion-text {\n  letter-spacing: 1px;\n}\n\n.flex {\n  padding: 10px 0;\n}\n\n.fullDiv {\n  width: 100%;\n  height: 100%;\n  padding: 10px;\n}\n\n.center {\n  display: grid;\n  justify-content: center;\n  text-align: center;\n}\n\n.each-box {\n  background: #004481;\n}\n\n.no-expenses-wrapper {\n  display: flex;\n  justify-content: center;\n}\n\n.no-expenses {\n  line-height: 25px;\n  letter-spacing: 1px;\n  width: 80vw;\n  margin-top: 23vh;\n}\n\nion-button {\n  margin-top: 15px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInRhYjIucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBRUcsYUFBQTtFQUNBLHVCQUFBO0VBQ0EsbUJBQUE7RUFDQSxtQkFBQTtFQUNBLFlBQUE7RUFDQSxZQUFBO0FBQUg7O0FBRUE7RUFFRyxrQkFBQTtBQUFIOztBQUVBO0VBRUcsY0FBQTtFQUNBLFlBQUE7RUFDQSxtQkFBQTtFQUNBLGlDQUFBO0VBQ0EsaUJBQUE7RUFDQSxlQUFBO0VBQ0EsbUJBQUE7QUFBSDs7QUFFQTtFQUVHLGNBQUE7RUFDQSxZQUFBO0FBQUg7O0FBRUE7RUFFRyxnQkFBQTtFQUNBLG1CQUFBO0VBQ0EsaUNBQUE7RUFDQSxlQUFBO0VBQ0EsbUJBQUE7RUFDQSxZQUFBO0FBQUg7O0FBRUE7RUFFRyxpQkFBQTtFQUNBLFdBQUE7RUFDQSxlQUFBO0VBQ0Esc0JBQUE7QUFBSDs7QUFFQTtFQUVHLG1CQUFBO0FBQUg7O0FBRUE7RUFFRyxlQUFBO0FBQUg7O0FBRUE7RUFFRyxXQUFBO0VBQ0EsWUFBQTtFQUNBLGFBQUE7QUFBSDs7QUFFQTtFQUVHLGFBQUE7RUFDQSx1QkFBQTtFQUNBLGtCQUFBO0FBQUg7O0FBRUE7RUFFRyxtQkFBQTtBQUFIOztBQUVBO0VBRUssYUFBQTtFQUNBLHVCQUFBO0FBQUw7O0FBRUE7RUFFSyxpQkFBQTtFQUNBLG1CQUFBO0VBQ0EsV0FBQTtFQUNBLGdCQUFBO0FBQUw7O0FBRUE7RUFFSyxnQkFBQTtBQUFMIiwiZmlsZSI6InRhYjIucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmhlYWRlclxyXG57XHJcbiAgIGRpc3BsYXk6IGdyaWQ7XHJcbiAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gICBiYWNrZ3JvdW5kOiAjMDA0NDgxO1xyXG4gICB3aWR0aDogMTAwdnc7XHJcbiAgIGhlaWdodDogMTV2aDtcclxufVxyXG4uaGVhZGVyLWNvbnRhaW5lclxyXG57XHJcbiAgIHRleHQtYWxpZ246IGNlbnRlclxyXG59XHJcbi5ib2xkZXJcclxue1xyXG4gICBmb250LXNpemU6IDRlbTtcclxuICAgY29sb3I6IHdoaXRlO1xyXG4gICBmb250LXdlaWdodDogYm9sZGVyO1xyXG4gICB0ZXh0LXNoYWRvdzogMC41cHggLjVweCAxcHggIzAwMDtcclxuICAgbGluZS1oZWlnaHQ6IDcwcHg7XHJcbiAgIG1hcmdpbi10b3A6IDBweDtcclxuICAgbGV0dGVyLXNwYWNpbmc6IDFweDtcclxufVxyXG5oNVxyXG57XHJcbiAgIGZvbnQtc2l6ZTogMWVtO1xyXG4gICBjb2xvcjogd2hpdGU7XHJcbn1cclxuLmJvbGRcclxue1xyXG4gICBmb250LXNpemU6IDEuN2VtO1xyXG4gICBmb250LXdlaWdodDogYm9sZGVyO1xyXG4gICB0ZXh0LXNoYWRvdzogMC41cHggLjVweCAxcHggIzAwMDtcclxuICAgbWFyZ2luLXRvcDogMHB4O1xyXG4gICBsZXR0ZXItc3BhY2luZzogMXB4O1xyXG4gICBjb2xvcjogd2hpdGU7XHJcbn1cclxuaW9uLWl0ZW1cclxue1xyXG4gICBtYXJnaW46IDMwcHggYXV0bztcclxuICAgd2lkdGg6IDkwdnc7XHJcbiAgIHBhZGRpbmc6IDE1cHggMDtcclxuICAgLS1ib3JkZXItcmFkaXVzOiAxMHB4XHJcbn1cclxuaW9uLXRleHRcclxue1xyXG4gICBsZXR0ZXItc3BhY2luZzogMXB4O1xyXG59XHJcbi5mbGV4XHJcbntcclxuICAgcGFkZGluZzogMTBweCAwO1xyXG59XHJcbi5mdWxsRGl2XHJcbntcclxuICAgd2lkdGg6IDEwMCU7XHJcbiAgIGhlaWdodDoxMDAlO1xyXG4gICBwYWRkaW5nOiAxMHB4O1xyXG59XHJcbi5jZW50ZXJcclxue1xyXG4gICBkaXNwbGF5OiBncmlkO1xyXG4gICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG59XHJcbi5lYWNoLWJveFxyXG57XHJcbiAgIGJhY2tncm91bmQ6ICMwMDQ0ODE7XHJcbn1cclxuLm5vLWV4cGVuc2VzLXdyYXBwZXJcclxue1xyXG4gICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbn1cclxuLm5vLWV4cGVuc2VzXHJcbntcclxuICAgICBsaW5lLWhlaWdodDogMjVweDtcclxuICAgICBsZXR0ZXItc3BhY2luZzogMXB4O1xyXG4gICAgIHdpZHRoOiA4MHZ3O1xyXG4gICAgIG1hcmdpbi10b3A6IDIzdmg7XHJcbn1cclxuaW9uLWJ1dHRvblxyXG57XHJcbiAgICAgbWFyZ2luLXRvcDogMTVweDtcclxufVxyXG4iXX0= */";

/***/ })

}]);
//# sourceMappingURL=src_app_tab2_tab2_module_ts.js.map