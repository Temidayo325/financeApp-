"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_register_register_module_ts"],{

/***/ 9455:
/*!*****************************************************!*\
  !*** ./src/app/register/register-routing.module.ts ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "RegisterPageRoutingModule": () => (/* binding */ RegisterPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 8806);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 4001);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 3252);
/* harmony import */ var _register_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./register.page */ 6414);




const routes = [
    {
        path: '',
        component: _register_page__WEBPACK_IMPORTED_MODULE_0__.RegisterPage
    }
];
let RegisterPageRoutingModule = class RegisterPageRoutingModule {
};
RegisterPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], RegisterPageRoutingModule);



/***/ }),

/***/ 9204:
/*!*********************************************!*\
  !*** ./src/app/register/register.module.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "RegisterPageModule": () => (/* binding */ RegisterPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 8806);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 4001);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 8267);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 8346);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 8099);
/* harmony import */ var _register_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./register-routing.module */ 9455);
/* harmony import */ var _register_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./register.page */ 6414);







let RegisterPageModule = class RegisterPageModule {
};
RegisterPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _register_routing_module__WEBPACK_IMPORTED_MODULE_0__.RegisterPageRoutingModule
        ],
        declarations: [_register_page__WEBPACK_IMPORTED_MODULE_1__.RegisterPage]
    })
], RegisterPageModule);



/***/ }),

/***/ 6414:
/*!*******************************************!*\
  !*** ./src/app/register/register.page.ts ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "RegisterPage": () => (/* binding */ RegisterPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 8806);
/* harmony import */ var _C_wamp64_www_financeApp_node_modules_ngtools_webpack_src_loaders_direct_resource_js_register_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !./node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./register.page.html */ 3420);
/* harmony import */ var _register_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./register.page.scss */ 1304);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ 4001);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ 8099);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/router */ 3252);
/* harmony import */ var _Service_person_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../Service/person.service */ 1759);
/* harmony import */ var _Service_information_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../Service/information.service */ 3259);








let RegisterPage = class RegisterPage {
    constructor(toastCtrl, loadingctrl, navctrl, router, person, info) {
        this.toastCtrl = toastCtrl;
        this.loadingctrl = loadingctrl;
        this.navctrl = navctrl;
        this.router = router;
        this.person = person;
        this.info = info;
        this.user = { name: '', email: '', phoneNumber: '', gender: '', password: '', password2: '' };
        this.hidePassword = true;
        this.passwordType = 'password';
        this.hideConfirmPassword = true;
        this.passwordConfirmType = 'password';
    }
    ngOnInit() {
    }
    presentLoading(message) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__awaiter)(this, void 0, void 0, function* () {
            const loading = yield this.loadingctrl.create({
                cssClass: 'my-custom-class',
                message: message,
                spinner: "lines-sharp",
                backdropDismiss: true,
                id: 'loader'
            });
            yield loading.present();
        });
    }
    presentToast(message, time = 4000, type = "dark") {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__awaiter)(this, void 0, void 0, function* () {
            const toast = yield this.toastCtrl.create({
                message: message,
                position: "bottom",
                color: type,
                duration: time
            });
            toast.present();
        });
    }
    validateData(data) {
        for (let [key, value] of Object.entries(data)) {
            if (value == undefined || value == null || value.length <= 3) {
                return key + " is Invalid";
            }
        }
    }
    login() {
        this.router.navigate(['/login']);
    }
    register() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__awaiter)(this, void 0, void 0, function* () {
            yield this.presentLoading("Creating your account ......");
            let checked = this.validateData(this.user);
            if (checked) {
                this.loadingctrl.dismiss();
                this.presentToast(checked);
            }
            else {
                if (this.user.password === this.user.password2) {
                    this.person.Signup(this.user).subscribe(response => {
                        console.log(response);
                        let parsed = (typeof response == 'object') ? response : JSON.parse(response);
                        if (parsed.status === 1) {
                            this.loadingctrl.dismiss();
                            this.presentToast("Your registration is successful.", 5000, "dark");
                            this.info.store(parsed.data);
                            localStorage.setItem("email", parsed.data.email);
                            localStorage.setItem("user_id", parsed.data.user_id);
                            setTimeout(() => {
                                this.router.navigate(['/verify-password']);
                            }, 5000);
                        }
                        else {
                            this.loadingctrl.dismiss();
                            this.presentToast(parsed.message, 5000, "dark");
                            console.log(parsed);
                        }
                    }, (error) => {
                        console.log(error);
                    });
                }
                else {
                    this.loadingctrl.dismiss();
                    this.presentToast("The passwords do not match");
                }
            }
        });
    }
    viewPassword() {
        this.hidePassword = !this.hidePassword;
        this.passwordType = (this.hidePassword) ? 'password' : 'text';
    }
    viewConfirmPassword() {
        this.hideConfirmPassword = !this.hideConfirmPassword;
        this.passwordConfirmType = (this.hideConfirmPassword) ? 'password' : 'text';
    }
};
RegisterPage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.ToastController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.LoadingController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.NavController },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_6__.Router },
    { type: _Service_person_service__WEBPACK_IMPORTED_MODULE_2__.PersonService },
    { type: _Service_information_service__WEBPACK_IMPORTED_MODULE_3__.InformationService }
];
RegisterPage = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_7__.Component)({
        selector: 'app-register',
        template: _C_wamp64_www_financeApp_node_modules_ngtools_webpack_src_loaders_direct_resource_js_register_page_html__WEBPACK_IMPORTED_MODULE_0__["default"],
        styles: [_register_page_scss__WEBPACK_IMPORTED_MODULE_1__]
    })
], RegisterPage);



/***/ }),

/***/ 3420:
/*!************************************************************************************************************!*\
  !*** ./node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./src/app/register/register.page.html ***!
  \************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-app>\r\n   <ion-header class=\"header\">\r\n      <div class=\"header-box\">\r\n         <ion-text class=\"bold\"  color=\"tertiary\"><h1>Track your Expenses</h1></ion-text>\r\n         <ion-text class=\"\"  color=\"tertiary\"><h4>Join the movement</h4></ion-text>\r\n      </div>\r\n   </ion-header>\r\n\r\n   <ion-content>\r\n      <div class=\"container\">\r\n         <ion-text class=\"bold\"  color=\"tertiary\">Sign up</ion-text>\r\n         <ion-item lines=\"none\" class=\"border\">\r\n           <ion-input placeholder=\"Full name\" type=\"text\" [(ngModel)]=\"user.name\" required></ion-input>\r\n         </ion-item>\r\n         <ion-item lines=\"none\" class=\"border\">\r\n           <ion-input placeholder=\"Email\" type=\"text\" [(ngModel)]=\"user.email\" required></ion-input>\r\n         </ion-item>\r\n         <ion-item lines=\"none\" class=\"border\">\r\n           <ion-input placeholder=\"09034567890\" type=\"text\" [(ngModel)]=\"user.phoneNumber\" required></ion-input>\r\n         </ion-item>\r\n         <ion-item lines=\"none\" class=\"border\" required>\r\n            <ion-label position=\"floating\" >Gender</ion-label>\r\n            <ion-select [(ngModel)]=\"user.gender\">\r\n                <ion-select-option value=\"female\">Female</ion-select-option>\r\n                <ion-select-option value=\"male\">Male</ion-select-option>\r\n           </ion-select>\r\n         </ion-item>\r\n         <ion-item lines=\"none\" class=\"border\" required>\r\n           <ion-input placeholder=\"Password\" [type]=\"passwordType\" [(ngModel)]=\"user.password\"></ion-input>\r\n           <ion-icon name=\"eye\" (click)=\"viewPassword()\" *ngIf=\"hidePassword\"></ion-icon>\r\n           <ion-icon name=\"eye-off\" (click)=\"viewPassword()\" *ngIf=\"!hidePassword\"></ion-icon>\r\n         </ion-item>\r\n         <ion-item lines=\"none\" class=\"border\" required>\r\n           <ion-input placeholder=\"Confirm Password\" [type]=\"passwordConfirmType\" [(ngModel)]=\"user.password2\"></ion-input>\r\n           <ion-icon name=\"eye\" (click)=\"viewConfirmPassword()\" *ngIf=\"hideConfirmPassword\"></ion-icon>\r\n           <ion-icon name=\"eye-off\" (click)=\"viewConfirmPassword()\" *ngIf=\"!hideConfirmPassword\"></ion-icon>\r\n         </ion-item>\r\n         <!-- <ion-item lines=\"none\" class=\"grid\"> -->\r\n         <div>\r\n            <ion-button size=\"large\" expand=\"block\" color=\"tertiary\" (click)=\"register()\">Sign up</ion-button>\r\n            <!-- <ion-text class=\"forgot\" (click)=\"forgotPassword()\">already have an </ion-text> -->\r\n         </div>\r\n\r\n\r\n         <!-- </ion-item> -->\r\n         <div class=\"footer\">\r\n            <ion-text class=\"footer text\">Already have an account? <span class=\"sign\" (click)=\"login()\">Log in</span></ion-text>\r\n         </div>\r\n      </div>\r\n   </ion-content>\r\n   <!-- <ion-footer>\r\n      <!-- <ion-toolbar>\r\n         <ion-text class=\"footer text\">Already have an account? <span class=\"sign\" (click)=\"login()\">Log in</span></ion-text>\r\n      <!-- </ion-toolbar>\r\n   </ion-footer> -->\r\n</ion-app>\r\n");

/***/ }),

/***/ 1304:
/*!*********************************************!*\
  !*** ./src/app/register/register.page.scss ***!
  \*********************************************/
/***/ ((module) => {

module.exports = ".header {\n  background-image: url('register.jpg');\n  background-size: cover;\n  background-repeat: no-repeat;\n  height: 30vh;\n  width: 100vw;\n}\n\n.header-box {\n  margin: 10% auto;\n  color: black;\n  padding: 20px;\n}\n\n.text {\n  letter-spacing: 1px;\n  line-height: 20px;\n}\n\n.bold {\n  font-weight: bolder;\n  text-align: left;\n  margin-bottom: 30px;\n  line-height: 40px;\n  font-size: 1.2em;\n  text-shadow: 0.5px 0.5px 1px #000000;\n}\n\n.container {\n  padding: 30px;\n}\n\n.border {\n  border: solid thin #000;\n  border-radius: 20px;\n  margin: 20px 0;\n}\n\n.grid {\n  display: grid;\n}\n\n.footer {\n  margin-top: 20px;\n}\n\n.sign {\n  color: #004481;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInJlZ2lzdGVyLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNHLHFDQUFBO0VBQ0Esc0JBQUE7RUFDQSw0QkFBQTtFQUNBLFlBQUE7RUFDQSxZQUFBO0FBQ0g7O0FBQ0E7RUFHRyxnQkFBQTtFQUNBLFlBQUE7RUFDQSxhQUFBO0FBQUg7O0FBRUE7RUFFRyxtQkFBQTtFQUNBLGlCQUFBO0FBQUg7O0FBRUE7RUFFRyxtQkFBQTtFQUNBLGdCQUFBO0VBQ0EsbUJBQUE7RUFDQSxpQkFBQTtFQUNBLGdCQUFBO0VBQ0Esb0NBQUE7QUFBSDs7QUFFQTtFQUVHLGFBQUE7QUFBSDs7QUFHQTtFQUVHLHVCQUFBO0VBQ0EsbUJBQUE7RUFDQSxjQUFBO0FBREg7O0FBR0E7RUFDRyxhQUFBO0FBQUg7O0FBRUE7RUFFRyxnQkFBQTtBQUFIOztBQUVBO0VBRUcsY0FBQTtBQUFIIiwiZmlsZSI6InJlZ2lzdGVyLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5oZWFkZXJ7XHJcbiAgIGJhY2tncm91bmQtaW1hZ2U6IHVybCgnLi4vLi4vYXNzZXRzL3JlZ2lzdGVyLmpwZycpO1xyXG4gICBiYWNrZ3JvdW5kLXNpemU6IGNvdmVyO1xyXG4gICBiYWNrZ3JvdW5kLXJlcGVhdDogbm8tcmVwZWF0O1xyXG4gICBoZWlnaHQ6IDMwdmg7XHJcbiAgIHdpZHRoOiAxMDB2dztcclxufVxyXG4uaGVhZGVyLWJveFxyXG57XHJcbiAgIC8vIGRpc3BsYXk6IGdyaWQ7XHJcbiAgIG1hcmdpbjogMTAlIGF1dG87XHJcbiAgIGNvbG9yOiBibGFjaztcclxuICAgcGFkZGluZzogMjBweDtcclxufVxyXG4udGV4dFxyXG57XHJcbiAgIGxldHRlci1zcGFjaW5nOiAxcHg7XHJcbiAgIGxpbmUtaGVpZ2h0OiAyMHB4O1xyXG59XHJcbi5ib2xkXHJcbntcclxuICAgZm9udC13ZWlnaHQ6IGJvbGRlcjtcclxuICAgdGV4dC1hbGlnbjogbGVmdDtcclxuICAgbWFyZ2luLWJvdHRvbTogMzBweDtcclxuICAgbGluZS1oZWlnaHQ6IDQwcHg7XHJcbiAgIGZvbnQtc2l6ZTogMS4yZW07XHJcbiAgIHRleHQtc2hhZG93OiAwLjVweCAuNXB4IDFweCAjMDAwMDAwO1xyXG59XHJcbi5jb250YWluZXJcclxue1xyXG4gICBwYWRkaW5nOiAzMHB4O1xyXG4gICAvLyBtYXJnaW4tdG9wOiAxMHB4O1xyXG59XHJcbi5ib3JkZXJcclxue1xyXG4gICBib3JkZXI6IHNvbGlkIHRoaW4gIzAwMDtcclxuICAgYm9yZGVyLXJhZGl1czogMjBweDtcclxuICAgbWFyZ2luOiAyMHB4IDA7XHJcbn1cclxuLmdyaWR7XHJcbiAgIGRpc3BsYXk6IGdyaWQ7XHJcbn1cclxuLmZvb3RlclxyXG57XHJcbiAgIG1hcmdpbi10b3A6IDIwcHg7XHJcbn1cclxuLnNpZ25cclxue1xyXG4gICBjb2xvcjogIzAwNDQ4MTtcclxuICAgLy8gcGFkZGluZy1sZWZ0OiAxMHB4O1xyXG59XHJcbiJdfQ== */";

/***/ })

}]);
//# sourceMappingURL=src_app_register_register_module_ts.js.map