"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_verify-password_verify-password_module_ts"],{

/***/ 7988:
/*!*******************************************************************!*\
  !*** ./src/app/verify-password/verify-password-routing.module.ts ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "VerifyPasswordPageRoutingModule": () => (/* binding */ VerifyPasswordPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 8806);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 4001);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 3252);
/* harmony import */ var _verify_password_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./verify-password.page */ 8739);




const routes = [
    {
        path: '',
        component: _verify_password_page__WEBPACK_IMPORTED_MODULE_0__.VerifyPasswordPage
    }
];
let VerifyPasswordPageRoutingModule = class VerifyPasswordPageRoutingModule {
};
VerifyPasswordPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], VerifyPasswordPageRoutingModule);



/***/ }),

/***/ 4236:
/*!***********************************************************!*\
  !*** ./src/app/verify-password/verify-password.module.ts ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "VerifyPasswordPageModule": () => (/* binding */ VerifyPasswordPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 8806);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 4001);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 8267);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 8346);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 8099);
/* harmony import */ var _verify_password_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./verify-password-routing.module */ 7988);
/* harmony import */ var _verify_password_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./verify-password.page */ 8739);







let VerifyPasswordPageModule = class VerifyPasswordPageModule {
};
VerifyPasswordPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _verify_password_routing_module__WEBPACK_IMPORTED_MODULE_0__.VerifyPasswordPageRoutingModule
        ],
        declarations: [_verify_password_page__WEBPACK_IMPORTED_MODULE_1__.VerifyPasswordPage]
    })
], VerifyPasswordPageModule);



/***/ }),

/***/ 8739:
/*!*********************************************************!*\
  !*** ./src/app/verify-password/verify-password.page.ts ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "VerifyPasswordPage": () => (/* binding */ VerifyPasswordPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 8806);
/* harmony import */ var _C_wamp64_www_financeApp_node_modules_ngtools_webpack_src_loaders_direct_resource_js_verify_password_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !./node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./verify-password.page.html */ 7010);
/* harmony import */ var _verify_password_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./verify-password.page.scss */ 7486);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ 4001);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ 8099);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/router */ 3252);
/* harmony import */ var _Service_person_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../Service/person.service */ 1759);
/* harmony import */ var _Service_information_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../Service/information.service */ 3259);








let VerifyPasswordPage = class VerifyPasswordPage {
    constructor(toastCtrl, loadingctrl, navctrl, router, person, info) {
        this.toastCtrl = toastCtrl;
        this.loadingctrl = loadingctrl;
        this.navctrl = navctrl;
        this.router = router;
        this.person = person;
        this.info = info;
    }
    ngOnInit() {
    }
    verify() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__awaiter)(this, void 0, void 0, function* () {
            yield this.presentLoading("Verifying your account...");
            if (this.code == undefined || this.code == null || this.code.length <= 5) {
                this.loadingctrl.dismiss();
                this.presentToast("The code you entered is invalid");
            }
            else {
                const user = this.info.retrieve();
                console.log(user);
                this.person.verifyCode({ user_id: localStorage.getItem("user_id"), code: this.code }).subscribe((response) => {
                    let information = (typeof response == 'object') ? response : JSON.parse(response);
                    console.log(information);
                    if (information.status == 1) {
                        this.loadingctrl.dismiss();
                        this.presentToast(information.message);
                        // setTimeout(() => {
                        this.router.navigate(['/login']);
                        // }, 4000)
                    }
                    else {
                        this.loadingctrl.dismiss();
                        this.presentToast(information.message);
                    }
                }, (error) => {
                    console.log(error);
                });
            }
        });
    }
    presentLoading(message) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__awaiter)(this, void 0, void 0, function* () {
            const loading = yield this.loadingctrl.create({
                cssClass: 'my-custom-class',
                message: message,
                spinner: "lines-sharp",
                backdropDismiss: true,
                id: 'loader'
            });
            yield loading.present();
        });
    }
    presentToast(message, time = 4000, type = "dark") {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__awaiter)(this, void 0, void 0, function* () {
            const toast = yield this.toastCtrl.create({
                message: message,
                position: "bottom",
                color: type,
                duration: time
            });
            toast.present();
        });
    }
};
VerifyPasswordPage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.ToastController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.LoadingController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.NavController },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_6__.Router },
    { type: _Service_person_service__WEBPACK_IMPORTED_MODULE_2__.PersonService },
    { type: _Service_information_service__WEBPACK_IMPORTED_MODULE_3__.InformationService }
];
VerifyPasswordPage = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_7__.Component)({
        selector: 'app-verify-password',
        template: _C_wamp64_www_financeApp_node_modules_ngtools_webpack_src_loaders_direct_resource_js_verify_password_page_html__WEBPACK_IMPORTED_MODULE_0__["default"],
        styles: [_verify_password_page_scss__WEBPACK_IMPORTED_MODULE_1__]
    })
], VerifyPasswordPage);



/***/ }),

/***/ 7010:
/*!**************************************************************************************************************************!*\
  !*** ./node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./src/app/verify-password/verify-password.page.html ***!
  \**************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-app>\r\n   <ion-header class=\"header\">\r\n      <!-- <div class=\"header-box\">\r\n         <ion-text class=\"bold\"><h1>Verify your account</h1></ion-text>\r\n      </div> -->\r\n   </ion-header>\r\n\r\n   <ion-content>\r\n      <div class=\"container\">\r\n         <ion-text class=\"bold\">Verify your Email</ion-text>\r\n         <div>\r\n            <ion-item lines=\"none\" class=\"border\">\r\n              <!-- <ion-label position=\"stacked\">Email</ion-label> -->\r\n              <ion-input placeholder=\"verification code\" type=\"text\" [(ngModel)]=\"code\"></ion-input>\r\n            </ion-item>\r\n            <div>\r\n               <ion-button size=\"large\" expand=\"block\" color=\"tertiary\" (click)=\"verify()\">Verify Password</ion-button>\r\n               <ion-text class=\"forgot\" (click)=\"forgotPassword()\">Resend verification code</ion-text>\r\n            </div>\r\n         </div>\r\n      </div>\r\n   </ion-content>\r\n\r\n</ion-app>\r\n");

/***/ }),

/***/ 7486:
/*!***********************************************************!*\
  !*** ./src/app/verify-password/verify-password.page.scss ***!
  \***********************************************************/
/***/ ((module) => {

module.exports = ".header {\n  background-image: url('verify.png');\n  background-size: contain;\n  background-repeat: no-repeat;\n  height: 30vh;\n  width: 100vw;\n}\n\n.header-box {\n  margin: 16% auto;\n  color: black;\n  padding: 20px;\n}\n\n.bold {\n  font-weight: bolder;\n  text-align: left;\n  margin-bottom: 30px;\n  line-height: 40px;\n  font-size: 1.1em;\n}\n\n.container {\n  padding: 30px;\n  margin-top: 10px;\n}\n\n.border {\n  border: solid thin #000;\n  border-radius: 20px;\n  margin: 30px 0;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInZlcmlmeS1wYXNzd29yZC5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRyxtQ0FBQTtFQUNBLHdCQUFBO0VBQ0EsNEJBQUE7RUFDQSxZQUFBO0VBQ0EsWUFBQTtBQUNIOztBQUNBO0VBR0csZ0JBQUE7RUFDQSxZQUFBO0VBQ0EsYUFBQTtBQUFIOztBQUVBO0VBRUcsbUJBQUE7RUFDQSxnQkFBQTtFQUNBLG1CQUFBO0VBQ0EsaUJBQUE7RUFDQSxnQkFBQTtBQUFIOztBQUVBO0VBRUcsYUFBQTtFQUNBLGdCQUFBO0FBQUg7O0FBRUE7RUFFRyx1QkFBQTtFQUNBLG1CQUFBO0VBQ0EsY0FBQTtBQUFIIiwiZmlsZSI6InZlcmlmeS1wYXNzd29yZC5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuaGVhZGVye1xyXG4gICBiYWNrZ3JvdW5kLWltYWdlOiB1cmwoJy4uLy4uL2Fzc2V0cy92ZXJpZnkucG5nJyk7XHJcbiAgIGJhY2tncm91bmQtc2l6ZTogY29udGFpbjtcclxuICAgYmFja2dyb3VuZC1yZXBlYXQ6IG5vLXJlcGVhdDtcclxuICAgaGVpZ2h0OiAzMHZoO1xyXG4gICB3aWR0aDogMTAwdnc7XHJcbn1cclxuLmhlYWRlci1ib3hcclxue1xyXG4gICAvLyBkaXNwbGF5OiBncmlkO1xyXG4gICBtYXJnaW46IDE2JSBhdXRvO1xyXG4gICBjb2xvcjogYmxhY2s7XHJcbiAgIHBhZGRpbmc6IDIwcHg7XHJcbn1cclxuLmJvbGRcclxue1xyXG4gICBmb250LXdlaWdodDogYm9sZGVyO1xyXG4gICB0ZXh0LWFsaWduOiBsZWZ0O1xyXG4gICBtYXJnaW4tYm90dG9tOiAzMHB4O1xyXG4gICBsaW5lLWhlaWdodDogNDBweDtcclxuICAgZm9udC1zaXplOiAxLjFlbTtcclxufVxyXG4uY29udGFpbmVyXHJcbntcclxuICAgcGFkZGluZzogMzBweDtcclxuICAgbWFyZ2luLXRvcDogMTBweDtcclxufVxyXG4uYm9yZGVyXHJcbntcclxuICAgYm9yZGVyOiBzb2xpZCB0aGluICMwMDA7XHJcbiAgIGJvcmRlci1yYWRpdXM6IDIwcHg7XHJcbiAgIG1hcmdpbjogMzBweCAwO1xyXG59XHJcbiJdfQ== */";

/***/ })

}]);
//# sourceMappingURL=src_app_verify-password_verify-password_module_ts.js.map