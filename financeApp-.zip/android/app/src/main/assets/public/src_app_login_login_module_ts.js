"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_login_login_module_ts"],{

/***/ 7210:
/*!*********************************************************************************!*\
  !*** ./node_modules/@awesome-cordova-plugins/network/__ivy_ngcc__/ngx/index.js ***!
  \*********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Connection": () => (/* binding */ Connection),
/* harmony export */   "Network": () => (/* binding */ Network)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 8806);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 4001);
/* harmony import */ var _awesome_cordova_plugins_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @awesome-cordova-plugins/core */ 4662);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs */ 4850);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs/operators */ 3301);






var Connection;
(function (Connection) {
    Connection["UNKNOWN"] = "unknown";
    Connection["ETHERNET"] = "ethernet";
    Connection["WIFI"] = "wifi";
    Connection["CELL_2G"] = "2g";
    Connection["CELL_3G"] = "3g";
    Connection["CELL_4G"] = "4g";
    Connection["CELL"] = "cellular";
    Connection["NONE"] = "none";
})(Connection || (Connection = {}));
var Network = /** @class */ (function (_super) {
    (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__extends)(Network, _super);
    function Network() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        /**
         * Constants for possible connection types
         */
        _this.Connection = {
            UNKNOWN: 'unknown',
            ETHERNET: 'ethernet',
            WIFI: 'wifi',
            CELL_2G: '2g',
            CELL_3G: '3g',
            CELL_4G: '4g',
            CELL: 'cellular',
            NONE: 'none',
        };
        return _this;
    }
    Network.prototype.onChange = function () {
        var _this = this;
        return (function () {
            if ((0,_awesome_cordova_plugins_core__WEBPACK_IMPORTED_MODULE_0__.checkAvailability)(_this) === true) {
                return (0,rxjs__WEBPACK_IMPORTED_MODULE_2__.merge)(_this.onConnect().pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_3__.mapTo)('connected')), _this.onDisconnect().pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_3__.mapTo)('disconnected')));
            }
        })();
    };
    Network.prototype.onDisconnect = function () { return (0,_awesome_cordova_plugins_core__WEBPACK_IMPORTED_MODULE_0__.cordova)(this, "onDisconnect", { "eventObservable": true, "event": "offline", "element": "document" }, arguments); };
    Network.prototype.onConnect = function () { return (0,_awesome_cordova_plugins_core__WEBPACK_IMPORTED_MODULE_0__.cordova)(this, "onConnect", { "eventObservable": true, "event": "online", "element": "document" }, arguments); };
    Object.defineProperty(Network.prototype, "type", {
        get: function () { return (0,_awesome_cordova_plugins_core__WEBPACK_IMPORTED_MODULE_0__.cordovaPropertyGet)(this, "type"); },
        set: function (value) { (0,_awesome_cordova_plugins_core__WEBPACK_IMPORTED_MODULE_0__.cordovaPropertySet)(this, "type", value); },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Network.prototype, "downlinkMax", {
        get: function () { return (0,_awesome_cordova_plugins_core__WEBPACK_IMPORTED_MODULE_0__.cordovaPropertyGet)(this, "downlinkMax"); },
        set: function (value) { (0,_awesome_cordova_plugins_core__WEBPACK_IMPORTED_MODULE_0__.cordovaPropertySet)(this, "downlinkMax", value); },
        enumerable: false,
        configurable: true
    });
    Network.pluginName = "Network";
    Network.plugin = "cordova-plugin-network-information";
    Network.pluginRef = "navigator.connection";
    Network.repo = "https://github.com/apache/cordova-plugin-network-information";
    Network.platforms = ["Amazon Fire OS", "Android", "Browser", "iOS", "Windows"];
Network.ɵfac = /*@__PURE__*/ function () { var ɵNetwork_BaseFactory; return function Network_Factory(t) { return (ɵNetwork_BaseFactory || (ɵNetwork_BaseFactory = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵgetInheritedFactory"](Network)))(t || Network); }; }();
Network.ɵprov = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdefineInjectable"]({ token: Network, factory: function (t) { return Network.ɵfac(t); } });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵsetClassMetadata"](Network, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_4__.Injectable
    }], null, null); })();
    return Network;
}(_awesome_cordova_plugins_core__WEBPACK_IMPORTED_MODULE_0__.AwesomeCordovaNativePlugin));




/***/ }),

/***/ 3301:
/*!****************************************************************!*\
  !*** ./node_modules/rxjs/_esm2015/internal/operators/mapTo.js ***!
  \****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "mapTo": () => (/* binding */ mapTo)
/* harmony export */ });
/* harmony import */ var _Subscriber__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../Subscriber */ 8412);

function mapTo(value) {
    return (source) => source.lift(new MapToOperator(value));
}
class MapToOperator {
    constructor(value) {
        this.value = value;
    }
    call(subscriber, source) {
        return source.subscribe(new MapToSubscriber(subscriber, this.value));
    }
}
class MapToSubscriber extends _Subscriber__WEBPACK_IMPORTED_MODULE_0__.Subscriber {
    constructor(destination, value) {
        super(destination);
        this.value = value;
    }
    _next(x) {
        this.destination.next(this.value);
    }
}


/***/ }),

/***/ 2359:
/*!***********************************************!*\
  !*** ./src/app/login/login-routing.module.ts ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "LoginPageRoutingModule": () => (/* binding */ LoginPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 8806);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 4001);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 3252);
/* harmony import */ var _login_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./login.page */ 955);




const routes = [
    {
        path: '',
        component: _login_page__WEBPACK_IMPORTED_MODULE_0__.LoginPage
    }
];
let LoginPageRoutingModule = class LoginPageRoutingModule {
};
LoginPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], LoginPageRoutingModule);



/***/ }),

/***/ 9549:
/*!***************************************!*\
  !*** ./src/app/login/login.module.ts ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "LoginPageModule": () => (/* binding */ LoginPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 8806);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 4001);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 8267);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 8346);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 8099);
/* harmony import */ var _login_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./login-routing.module */ 2359);
/* harmony import */ var _login_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./login.page */ 955);







let LoginPageModule = class LoginPageModule {
};
LoginPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _login_routing_module__WEBPACK_IMPORTED_MODULE_0__.LoginPageRoutingModule
        ],
        declarations: [_login_page__WEBPACK_IMPORTED_MODULE_1__.LoginPage]
    })
], LoginPageModule);



/***/ }),

/***/ 955:
/*!*************************************!*\
  !*** ./src/app/login/login.page.ts ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "LoginPage": () => (/* binding */ LoginPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 8806);
/* harmony import */ var _C_wamp64_www_financeApp_node_modules_ngtools_webpack_src_loaders_direct_resource_js_login_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !./node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./login.page.html */ 9403);
/* harmony import */ var _login_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./login.page.scss */ 6051);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/core */ 4001);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 8099);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/router */ 3252);
/* harmony import */ var _Service_person_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../Service/person.service */ 1759);
/* harmony import */ var _Service_information_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../Service/information.service */ 3259);
/* harmony import */ var _awesome_cordova_plugins_network_ngx__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @awesome-cordova-plugins/network/ngx */ 7210);









let LoginPage = class LoginPage {
    constructor(toastCtrl, loadingctrl, navctrl, router, person, info, network) {
        this.toastCtrl = toastCtrl;
        this.loadingctrl = loadingctrl;
        this.navctrl = navctrl;
        this.router = router;
        this.person = person;
        this.info = info;
        this.network = network;
        this.registeredEmail = localStorage.getItem("email");
        this.user = { email: (this.registeredEmail !== '') ? this.registeredEmail : '', password: '' };
        this.hidePassword = true;
        this.passwordType = 'password';
    }
    ngOnInit() {
    }
    ionViewWillEnter() {
        // watch network for a disconnection
        let disconnectSubscription = this.network.onDisconnect().subscribe(() => {
            this.presentToast("No internet connection");
        });
        // stop disconnect watch
        disconnectSubscription.unsubscribe();
    }
    checkNetwork() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
            setTimeout(() => {
                if (this.network.type !== 'none' && this.network.type !== '2g' && this.network.type !== 'unknown') {
                    this.login();
                }
                else {
                    this.presentToast("No internet connection");
                }
            }, 2000);
        });
    }
    login() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
            yield this.presentLoading("Logging in...");
            let connectSubscription = this.network.onConnect().subscribe(() => {
                console.log('network connected!');
                // We just got a connection but we need to wait briefly
                // before we determine the connection type. Might need to wait.
                // prior to doing any api requests as well.
                setTimeout(() => {
                    if (this.network.type !== 'wifi') {
                        console.log('we got a wifi connection, woohoo!');
                    }
                }, 3000);
            });
            let checked = this.validateData(this.user);
            if (checked) {
                // console.log(this.loading)
                this.loadingctrl.dismiss();
                this.presentToast(checked);
            }
            else {
                this.person.login(this.user).subscribe((data) => (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
                    console.log(data);
                    let parsed = (typeof data == 'object') ? data : JSON.parse(data);
                    console.log(typeof parsed);
                    if (parsed.status === 1) {
                        this.loadingctrl.dismiss();
                        this.presentToast("Your login is successful.", 5000, "dark");
                        localStorage.setItem("user", JSON.stringify(parsed.data));
                        localStorage.setItem("token", parsed.token);
                        this.info.store(parsed.data);
                        // this.info.storeToken(parsed.token)
                        // setTimeout( () => {
                        this.router.navigate(['/tabs/tab1']);
                        // }, 5000)
                    }
                    else if (parsed.status == 2) {
                        this.loadingctrl.dismiss();
                        this.presentToast(parsed.message, 10000, "dark");
                        this.info.store(parsed.user_id);
                        console.log(this.info.retrieve());
                        localStorage.setItem("user_id", parsed.user_id);
                        setTimeout(() => {
                            this.router.navigate(['/verify-password']);
                        }, 5000);
                    }
                    else {
                        this.loadingctrl.dismiss();
                        this.presentToast(parsed.message, 10000, "dark");
                        console.log(parsed.message);
                    }
                }));
            }
        });
    }
    forgotPassword() {
        this.router.navigate(['/forgot-password']);
    }
    register() {
        this.router.navigate(['/register']);
    }
    viewPassword() {
        this.hidePassword = !this.hidePassword;
        this.passwordType = (this.hidePassword) ? 'password' : 'text';
    }
    presentLoading(message) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
            const loading = yield this.loadingctrl.create({
                cssClass: 'my-custom-class',
                message: message,
                spinner: "lines-sharp",
                backdropDismiss: true,
                id: 'loader'
            });
            yield loading.present();
        });
    }
    presentToast(message, time = 4000, type = "dark") {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
            const toast = yield this.toastCtrl.create({
                message: message,
                position: "bottom",
                color: type,
                duration: time
            });
            toast.present();
        });
    }
    validateData(data) {
        for (let [key, value] of Object.entries(data)) {
            if (value == undefined || value == null || value.length < 5) {
                return key + " is Invalid";
            }
        }
    }
};
LoginPage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.ToastController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.LoadingController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.NavController },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_7__.Router },
    { type: _Service_person_service__WEBPACK_IMPORTED_MODULE_2__.PersonService },
    { type: _Service_information_service__WEBPACK_IMPORTED_MODULE_3__.InformationService },
    { type: _awesome_cordova_plugins_network_ngx__WEBPACK_IMPORTED_MODULE_4__.Network }
];
LoginPage = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_8__.Component)({
        selector: 'app-login',
        template: _C_wamp64_www_financeApp_node_modules_ngtools_webpack_src_loaders_direct_resource_js_login_page_html__WEBPACK_IMPORTED_MODULE_0__["default"],
        styles: [_login_page_scss__WEBPACK_IMPORTED_MODULE_1__]
    })
], LoginPage);



/***/ }),

/***/ 9403:
/*!******************************************************************************************************!*\
  !*** ./node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./src/app/login/login.page.html ***!
  \******************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-app>\r\n   <ion-header class=\"header\">\r\n      <div class=\"header-box\">\r\n         <ion-text class=\"bold\" color=\"tertiary\"><h1>Your Expense tracker</h1></ion-text>\r\n         <ion-text class=\"\"  color=\"tertiary\"><h4>Login to track</h4></ion-text>\r\n      </div>\r\n   </ion-header>\r\n\r\n   <ion-content>\r\n      <div class=\"container\">\r\n         <ion-text class=\"bold\"  color=\"tertiary\">Log in</ion-text>\r\n         <ion-item lines=\"none\" class=\"border\">\r\n           <!-- <ion-label position=\"stacked\">Email</ion-label> -->\r\n           <ion-input placeholder=\"Email\" type=\"text\" [(ngModel)]=\"user.email\"></ion-input>\r\n         </ion-item>\r\n         <ion-item lines=\"none\" class=\"border\">\r\n           <!-- <ion-label position=\"floating\">Password</ion-label> -->\r\n           <ion-input placeholder=\"Password\" [type]=\"passwordType\" [(ngModel)]=\"user.password\"></ion-input>\r\n           <ion-icon name=\"eye\" (click)=\"viewPassword()\" *ngIf=\"hidePassword\"></ion-icon>\r\n           <ion-icon name=\"eye-off\" (click)=\"viewPassword()\" *ngIf=\"!hidePassword\"></ion-icon>\r\n         </ion-item>\r\n         <!-- <ion-item lines=\"none\" class=\"grid\"> -->\r\n         <div>\r\n            <ion-button size=\"large\" expand=\"block\" color=\"tertiary\" (click)=\"login()\">Log in</ion-button>\r\n            <!-- <ion-text class=\"forgot\" (click)=\"forgotPassword()\">Forgot password</ion-text> -->\r\n         </div>\r\n         <div class=\"forgot\">\r\n            <ion-text (click)=\"forgotPassword()\">Forgot password</ion-text>\r\n         </div>\r\n\r\n         <!-- </ion-item> -->\r\n         <div class=\"forgot\">\r\n            <ion-text class=\"footer text\">Don't have an account? <span class=\"sign\" (click)=\"register()\"  color=\"tertiary\">Sign up</span></ion-text>\r\n         </div>\r\n      </div>\r\n   </ion-content>\r\n</ion-app>\r\n");

/***/ }),

/***/ 6051:
/*!***************************************!*\
  !*** ./src/app/login/login.page.scss ***!
  \***************************************/
/***/ ((module) => {

module.exports = ".header {\n  background-image: url('login.jpg');\n  background-size: cover;\n  background-repeat: no-repeat;\n  height: 30vh;\n  width: 100vw;\n}\n\n.header-box {\n  margin: 12% auto;\n  color: black;\n  padding: 20px;\n}\n\n.text {\n  letter-spacing: 1px;\n  line-height: 20px;\n}\n\n.bold {\n  font-weight: bolder;\n  text-align: left;\n  margin-bottom: 30px;\n  line-height: 40px;\n  font-size: 1.1em;\n  text-shadow: 0.5px 0.5px 1px #000000;\n}\n\n.container {\n  padding: 30px;\n}\n\n.border {\n  border: solid thin #000;\n  border-radius: 20px;\n  margin: 30px 0;\n}\n\n.grid {\n  display: grid;\n}\n\n.sign {\n  color: #004481;\n}\n\n.forgot {\n  margin-top: 30px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImxvZ2luLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNHLGtDQUFBO0VBQ0Esc0JBQUE7RUFDQSw0QkFBQTtFQUNBLFlBQUE7RUFDQSxZQUFBO0FBQ0g7O0FBQ0E7RUFHRyxnQkFBQTtFQUNBLFlBQUE7RUFDQSxhQUFBO0FBQUg7O0FBRUE7RUFFRyxtQkFBQTtFQUNBLGlCQUFBO0FBQUg7O0FBRUE7RUFFRyxtQkFBQTtFQUNBLGdCQUFBO0VBQ0EsbUJBQUE7RUFDQSxpQkFBQTtFQUNBLGdCQUFBO0VBQ0Msb0NBQUE7QUFBSjs7QUFFQTtFQUVHLGFBQUE7QUFBSDs7QUFFQTtFQUVHLHVCQUFBO0VBQ0EsbUJBQUE7RUFDQSxjQUFBO0FBQUg7O0FBRUE7RUFDRyxhQUFBO0FBQ0g7O0FBQ0E7RUFFRyxjQUFBO0FBQ0g7O0FBRUE7RUFFRyxnQkFBQTtBQUFIIiwiZmlsZSI6ImxvZ2luLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5oZWFkZXJ7XHJcbiAgIGJhY2tncm91bmQtaW1hZ2U6IHVybCgnLi4vLi4vYXNzZXRzL2xvZ2luLmpwZycpO1xyXG4gICBiYWNrZ3JvdW5kLXNpemU6IGNvdmVyO1xyXG4gICBiYWNrZ3JvdW5kLXJlcGVhdDogbm8tcmVwZWF0O1xyXG4gICBoZWlnaHQ6IDMwdmg7XHJcbiAgIHdpZHRoOiAxMDB2dztcclxufVxyXG4uaGVhZGVyLWJveFxyXG57XHJcbiAgIC8vIGRpc3BsYXk6IGdyaWQ7XHJcbiAgIG1hcmdpbjogMTIlIGF1dG87XHJcbiAgIGNvbG9yOiBibGFjaztcclxuICAgcGFkZGluZzogMjBweDtcclxufVxyXG4udGV4dFxyXG57XHJcbiAgIGxldHRlci1zcGFjaW5nOiAxcHg7XHJcbiAgIGxpbmUtaGVpZ2h0OiAyMHB4O1xyXG59XHJcbi5ib2xkXHJcbntcclxuICAgZm9udC13ZWlnaHQ6IGJvbGRlcjtcclxuICAgdGV4dC1hbGlnbjogbGVmdDtcclxuICAgbWFyZ2luLWJvdHRvbTogMzBweDtcclxuICAgbGluZS1oZWlnaHQ6IDQwcHg7XHJcbiAgIGZvbnQtc2l6ZTogMS4xZW07XHJcbiAgICB0ZXh0LXNoYWRvdzogLjVweCAuNXB4IDFweCAjMDAwMDAwO1xyXG59XHJcbi5jb250YWluZXJcclxue1xyXG4gICBwYWRkaW5nOiAzMHB4O1xyXG59XHJcbi5ib3JkZXJcclxue1xyXG4gICBib3JkZXI6IHNvbGlkIHRoaW4gIzAwMDtcclxuICAgYm9yZGVyLXJhZGl1czogMjBweDtcclxuICAgbWFyZ2luOiAzMHB4IDA7XHJcbn1cclxuLmdyaWR7XHJcbiAgIGRpc3BsYXk6IGdyaWQ7XHJcbn1cclxuLnNpZ25cclxue1xyXG4gICBjb2xvcjogIzAwNDQ4MTtcclxuICAgLy8gcGFkZGluZy1sZWZ0OiAxMHB4O1xyXG59XHJcbi5mb3Jnb3Rcclxue1xyXG4gICBtYXJnaW4tdG9wOiAzMHB4O1xyXG59XHJcbiJdfQ== */";

/***/ })

}]);
//# sourceMappingURL=src_app_login_login_module_ts.js.map