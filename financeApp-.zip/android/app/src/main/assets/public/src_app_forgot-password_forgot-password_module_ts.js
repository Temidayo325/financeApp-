"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_forgot-password_forgot-password_module_ts"],{

/***/ 8819:
/*!*******************************************************************!*\
  !*** ./src/app/forgot-password/forgot-password-routing.module.ts ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ForgotPasswordPageRoutingModule": () => (/* binding */ ForgotPasswordPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 8806);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 4001);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 3252);
/* harmony import */ var _forgot_password_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./forgot-password.page */ 8744);




const routes = [
    {
        path: '',
        component: _forgot_password_page__WEBPACK_IMPORTED_MODULE_0__.ForgotPasswordPage
    }
];
let ForgotPasswordPageRoutingModule = class ForgotPasswordPageRoutingModule {
};
ForgotPasswordPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], ForgotPasswordPageRoutingModule);



/***/ }),

/***/ 585:
/*!***********************************************************!*\
  !*** ./src/app/forgot-password/forgot-password.module.ts ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ForgotPasswordPageModule": () => (/* binding */ ForgotPasswordPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 8806);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 4001);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 8267);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 8346);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 8099);
/* harmony import */ var _forgot_password_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./forgot-password-routing.module */ 8819);
/* harmony import */ var _forgot_password_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./forgot-password.page */ 8744);







let ForgotPasswordPageModule = class ForgotPasswordPageModule {
};
ForgotPasswordPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _forgot_password_routing_module__WEBPACK_IMPORTED_MODULE_0__.ForgotPasswordPageRoutingModule
        ],
        declarations: [_forgot_password_page__WEBPACK_IMPORTED_MODULE_1__.ForgotPasswordPage]
    })
], ForgotPasswordPageModule);



/***/ }),

/***/ 8744:
/*!*********************************************************!*\
  !*** ./src/app/forgot-password/forgot-password.page.ts ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ForgotPasswordPage": () => (/* binding */ ForgotPasswordPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 8806);
/* harmony import */ var _C_wamp64_www_financeApp_node_modules_ngtools_webpack_src_loaders_direct_resource_js_forgot_password_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !./node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./forgot-password.page.html */ 747);
/* harmony import */ var _forgot_password_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./forgot-password.page.scss */ 3008);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 4001);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ 3252);
/* harmony import */ var _Service_person_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../Service/person.service */ 1759);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ 8099);







let ForgotPasswordPage = class ForgotPasswordPage {
    constructor(router, user, toastCtrl, loadingctrl) {
        this.router = router;
        this.user = user;
        this.toastCtrl = toastCtrl;
        this.loadingctrl = loadingctrl;
        this.MailHasBeenSent = false;
    }
    verifyCode() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(this, void 0, void 0, function* () {
            yield this.presentLoading("Verifying ...");
            if (this.code == undefined || this.code == null || this.code.length <= 5) {
                this.loadingctrl.dismiss();
                this.presentToast("The code you entered is invalid");
            }
            else {
                this.user.verifyCode({ user_id: this.userId, code: this.code }).subscribe((response) => {
                    let information = (typeof response == 'object') ? response : JSON.parse(response);
                    console.log(information);
                    if (information.status == 1) {
                        this.loadingctrl.dismiss();
                        this.presentToast(information.message);
                        this.router.navigate(['/change-password']);
                    }
                    else {
                        this.loadingctrl.dismiss();
                        this.presentToast(information.message);
                    }
                }, (error) => {
                    console.log(error);
                });
            }
        });
    }
    requestCode() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(this, void 0, void 0, function* () {
            yield this.presentLoading("Confirming your mail .......");
            this.user.ResetPassword(this.email).subscribe(response => {
                this.loadingctrl.dismiss();
                if (response.status == 0) {
                    this.presentToast(response.message);
                }
                else if (response.status == 1) {
                    this.presentToast(response.message);
                    this.userId = response.user_id;
                    this.MailHasBeenSent = true;
                }
                else {
                    this.presentToast("Something seems broken, retry in 2 minutes");
                }
            }, error => {
                this.loadingctrl.dismiss();
                this.presentToast(error);
            });
        });
    }
    back() {
        this.router.navigate(['/login']);
    }
    presentLoading(message) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(this, void 0, void 0, function* () {
            const loading = yield this.loadingctrl.create({
                cssClass: 'my-custom-class',
                message: message,
                spinner: "lines-sharp",
                backdropDismiss: true,
                id: 'loader'
            });
            yield loading.present();
        });
    }
    presentToast(message, time = 4000, type = "dark") {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(this, void 0, void 0, function* () {
            const toast = yield this.toastCtrl.create({
                message: message,
                position: "bottom",
                color: type,
                duration: time
            });
            toast.present();
        });
    }
};
ForgotPasswordPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__.Router },
    { type: _Service_person_service__WEBPACK_IMPORTED_MODULE_2__.PersonService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.ToastController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.LoadingController }
];
ForgotPasswordPage = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_6__.Component)({
        selector: 'app-forgot-password',
        template: _C_wamp64_www_financeApp_node_modules_ngtools_webpack_src_loaders_direct_resource_js_forgot_password_page_html__WEBPACK_IMPORTED_MODULE_0__["default"],
        styles: [_forgot_password_page_scss__WEBPACK_IMPORTED_MODULE_1__]
    })
], ForgotPasswordPage);



/***/ }),

/***/ 747:
/*!**************************************************************************************************************************!*\
  !*** ./node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./src/app/forgot-password/forgot-password.page.html ***!
  \**************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-app>\r\n     <ion-header class=\"header ion-no-border\">\r\n           <ion-text>\r\n                <ion-button (click)=\"back()\" fill=\"clear\">\r\n                     <ion-icon slot=\"icon-only\" name=\"arrow-back\"></ion-icon>\r\n                     <span class=\"\">Back</span>\r\n               </ion-button>\r\n           </ion-text>\r\n     </ion-header>\r\n     <ion-content>\r\n          <div class=\"content\">\r\n               <div *ngIf=\"MailHasBeenSent == true; else resetPassword\">\r\n                    <ion-text>\r\n                         <h1>Verify code</h1>\r\n                    </ion-text>\r\n                    <ion-text class=\"text\">A verification was sent to your email, kindly enter the verification code</ion-text>\r\n                    <ion-item lines=\"none\" class=\"border\">\r\n                         <ion-label position=\"stacked\">Verification code</ion-label>\r\n                         <ion-input [(ngModel)]=\"code\"></ion-input>\r\n                    </ion-item>\r\n                    <div class=\"flex\">\r\n                         <ion-button size=\"default\" color=\"primary\" (click)=\"verifyCode()\">Verify</ion-button>\r\n                    </div>\r\n               </div>\r\n               <ng-template #resetPassword>\r\n                    <ion-text>\r\n                         <h1>Reset Password</h1>\r\n                    </ion-text>\r\n                    <ion-text class=\"text\">Enter the Email associated with the account and we'll send the recovery innstructions to your </ion-text>\r\n                    <ion-item lines=\"none\" class=\"border\">\r\n                         <ion-label position=\"stacked\">Email Address</ion-label>\r\n                         <ion-input [(ngModel)]=\"email\"></ion-input>\r\n                    </ion-item>\r\n                    <div class=\"flex\">\r\n                         <ion-button size=\"default\" color=\"primary\" (click)=\"requestCode()\">Receive instructions</ion-button>\r\n                    </div>\r\n               </ng-template>\r\n          </div>\r\n     </ion-content>\r\n\r\n</ion-app>\r\n");

/***/ }),

/***/ 3008:
/*!***********************************************************!*\
  !*** ./src/app/forgot-password/forgot-password.page.scss ***!
  \***********************************************************/
/***/ ((module) => {

module.exports = ".header {\n  padding: 10px 0;\n}\n\nspan {\n  margin-left: 8px;\n}\n\n.content {\n  padding: 10px 15px;\n  letter-spacing: 1px;\n}\n\n.flex {\n  display: flex;\n  justify-content: center;\n}\n\nh1 {\n  line-height: 40px;\n}\n\n.border {\n  border: solid 2px white;\n  border-radius: 20px;\n  margin: 30px;\n}\n\n.text {\n  margin: 15px 0;\n  line-height: 20px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZvcmdvdC1wYXNzd29yZC5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFFSyxlQUFBO0FBQUw7O0FBRUE7RUFFSyxnQkFBQTtBQUFMOztBQUVBO0VBRUssa0JBQUE7RUFDQSxtQkFBQTtBQUFMOztBQUVBO0VBRUssYUFBQTtFQUNBLHVCQUFBO0FBQUw7O0FBRUE7RUFFSyxpQkFBQTtBQUFMOztBQUVBO0VBRUssdUJBQUE7RUFDQSxtQkFBQTtFQUNBLFlBQUE7QUFBTDs7QUFFQTtFQUVLLGNBQUE7RUFDQSxpQkFBQTtBQUFMIiwiZmlsZSI6ImZvcmdvdC1wYXNzd29yZC5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuaGVhZGVyXHJcbntcclxuICAgICBwYWRkaW5nOiAxMHB4IDA7XHJcbn1cclxuc3BhblxyXG57XHJcbiAgICAgbWFyZ2luLWxlZnQ6IDhweDtcclxufVxyXG4uY29udGVudFxyXG57XHJcbiAgICAgcGFkZGluZzogMTBweCAxNXB4O1xyXG4gICAgIGxldHRlci1zcGFjaW5nOiAxcHg7XHJcbn1cclxuLmZsZXhcclxue1xyXG4gICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbn1cclxuaDFcclxue1xyXG4gICAgIGxpbmUtaGVpZ2h0OiA0MHB4O1xyXG59XHJcbi5ib3JkZXJcclxue1xyXG4gICAgIGJvcmRlcjogc29saWQgMnB4IHdoaXRlIDtcclxuICAgICBib3JkZXItcmFkaXVzOiAyMHB4O1xyXG4gICAgIG1hcmdpbjogMzBweDtcclxufVxyXG4udGV4dFxyXG57XHJcbiAgICAgbWFyZ2luOiAxNXB4IDA7XHJcbiAgICAgbGluZS1oZWlnaHQ6IDIwcHg7XHJcbn1cclxuIl19 */";

/***/ })

}]);
//# sourceMappingURL=src_app_forgot-password_forgot-password_module_ts.js.map