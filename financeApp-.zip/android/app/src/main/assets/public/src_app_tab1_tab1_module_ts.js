"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_tab1_tab1_module_ts"],{

/***/ 8383:
/*!*********************************************!*\
  !*** ./src/app/tab1/tab1-routing.module.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Tab1PageRoutingModule": () => (/* binding */ Tab1PageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 8806);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 4001);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 3252);
/* harmony import */ var _tab1_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./tab1.page */ 2371);




const routes = [
    {
        path: '',
        component: _tab1_page__WEBPACK_IMPORTED_MODULE_0__.Tab1Page,
    }
];
let Tab1PageRoutingModule = class Tab1PageRoutingModule {
};
Tab1PageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule]
    })
], Tab1PageRoutingModule);



/***/ }),

/***/ 4265:
/*!*************************************!*\
  !*** ./src/app/tab1/tab1.module.ts ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Tab1PageModule": () => (/* binding */ Tab1PageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 8806);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ 8099);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 4001);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/common */ 8267);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/forms */ 8346);
/* harmony import */ var _tab1_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./tab1.page */ 2371);
/* harmony import */ var _explore_container_explore_container_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../explore-container/explore-container.module */ 456);
/* harmony import */ var _tab1_routing_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./tab1-routing.module */ 8383);








let Tab1PageModule = class Tab1PageModule {
};
Tab1PageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.NgModule)({
        imports: [
            _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.IonicModule,
            _angular_common__WEBPACK_IMPORTED_MODULE_6__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_7__.FormsModule,
            _explore_container_explore_container_module__WEBPACK_IMPORTED_MODULE_1__.ExploreContainerComponentModule,
            _tab1_routing_module__WEBPACK_IMPORTED_MODULE_2__.Tab1PageRoutingModule
        ],
        declarations: [_tab1_page__WEBPACK_IMPORTED_MODULE_0__.Tab1Page]
    })
], Tab1PageModule);



/***/ }),

/***/ 2371:
/*!***********************************!*\
  !*** ./src/app/tab1/tab1.page.ts ***!
  \***********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Tab1Page": () => (/* binding */ Tab1Page)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 8806);
/* harmony import */ var _C_wamp64_www_financeApp_node_modules_ngtools_webpack_src_loaders_direct_resource_js_tab1_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !./node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./tab1.page.html */ 123);
/* harmony import */ var _tab1_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./tab1.page.scss */ 8443);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ 4001);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ 3252);
/* harmony import */ var _Service_expense_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../Service/expense.service */ 4709);
/* harmony import */ var _Service_information_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../Service/information.service */ 3259);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 8099);








let Tab1Page = class Tab1Page {
    constructor(router, info, expense, toastCtrl, loadingctrl) {
        this.router = router;
        this.info = info;
        this.expense = expense;
        this.toastCtrl = toastCtrl;
        this.loadingctrl = loadingctrl;
        this.expenses = "00.00";
        this.income = "00.00";
    }
    ionViewWillEnter() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__awaiter)(this, void 0, void 0, function* () {
            yield this.presentLoading("Retrieving data...");
            const userData = JSON.parse(localStorage.getItem("user"));
            this.getFirstName(userData.name);
            this.expense.getExpenseOverview(userData.user_id, localStorage.getItem("token")).subscribe(response => {
                let parsed = (typeof response == 'object') ? response : JSON.parse(response);
                if (parsed.status == 0) {
                    this.loadingctrl.dismiss();
                    this.presentToast(parsed.message);
                    console.log(parsed);
                }
                else if (parsed.status == 1) {
                    this.loadingctrl.dismiss();
                    this.expenses = parsed.expenses;
                    localStorage.setItem("categories", JSON.stringify(parsed.categories));
                    this.categories = parsed.categories;
                    this.income = parsed.income;
                    // this.presentToast("Unable to retrieve current data")
                    console.log(parsed);
                }
                else {
                    this.loadingctrl.dismiss();
                    this.presentToast("Unable to retrieve current data");
                    console.log(parsed);
                }
            }, (error) => {
                console.log(error);
            });
        });
    }
    getFirstName(name) {
        let fullname = name.split(" ");
        this.name = fullname[1];
    }
    presentLoading(message) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__awaiter)(this, void 0, void 0, function* () {
            const loading = yield this.loadingctrl.create({
                cssClass: 'my-custom-class',
                message: message,
                spinner: "lines-sharp",
                backdropDismiss: true,
                id: 'loader'
            });
            yield loading.present();
        });
    }
    presentToast(message, time = 4000, type = "dark") {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__awaiter)(this, void 0, void 0, function* () {
            const toast = yield this.toastCtrl.create({
                message: message,
                position: "bottom",
                color: type,
                duration: time
            });
            toast.present();
        });
    }
    addExpense() {
        this.router.navigate(['/create-expense']);
    }
    addIncome() {
        this.router.navigate(['/create-income']);
    }
    viewExpense() {
        this.router.navigate(['/tabs/tab2']);
    }
    viewIncome() {
        this.router.navigate(['/tabs/tab3']);
    }
};
Tab1Page.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_5__.Router },
    { type: _Service_information_service__WEBPACK_IMPORTED_MODULE_3__.InformationService },
    { type: _Service_expense_service__WEBPACK_IMPORTED_MODULE_2__.ExpenseService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.ToastController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.LoadingController }
];
Tab1Page = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_7__.Component)({
        selector: 'app-tab1',
        template: _C_wamp64_www_financeApp_node_modules_ngtools_webpack_src_loaders_direct_resource_js_tab1_page_html__WEBPACK_IMPORTED_MODULE_0__["default"],
        styles: [_tab1_page_scss__WEBPACK_IMPORTED_MODULE_1__]
    })
], Tab1Page);



/***/ }),

/***/ 123:
/*!****************************************************************************************************!*\
  !*** ./node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./src/app/tab1/tab1.page.html ***!
  \****************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-app>\r\n   <ion-content fullscreen=\"true\">\r\n      <ion-header>\r\n         <ion-toolbar slots=\"start\" color=\"primary\" >\r\n            <ion-text class=\"bold\">\r\n            Hello {{name}}\r\n           </ion-text>\r\n           <!-- <ion-icon name=\"person-circle-outline\" slot=\"end\" class=\"header-icon\"></ion-icon> -->\r\n         </ion-toolbar>\r\n\r\n      </ion-header>\r\n      <ion-item color=\"primary\" slot=\"\" lines=\"none\" >\r\n         <div class=\"fullDiv\">\r\n            <h5>Expense</h5>\r\n            <ion-text>\r\n               <h3 class=\"bolder\">#{{expenses}}</h3>\r\n               <!-- <h4 class=\"small\">An overview of your Expenses</h4> -->\r\n            </ion-text>\r\n            <ion-button size=\"default\" color=\"tertiary\" class=\"card-button\" (click)=\"addExpense()\"><ion-icon name=\"add-circle-sharp\" slot=\"start\"></ion-icon>Add Expense</ion-button>\r\n         </div>\r\n      </ion-item>\r\n\r\n      <ion-item color=\"primary\" slot=\"\" lines=\"none\" >\r\n         <div class=\"fullDiv\">\r\n            <h5>Income</h5>\r\n            <ion-text>\r\n               <h3 class=\"bolder\">#{{income}}</h3>\r\n               <!-- <h4 class=\"small\">An overview of your Expenses</h4> -->\r\n            </ion-text>\r\n            <ion-button size=\"default\" color=\"tertiary\" class=\"card-button\" (click)=\"addIncome()\"><ion-icon name=\"add-circle-sharp\" slot=\"start\"></ion-icon>Add Income</ion-button>\r\n         </div>\r\n      </ion-item>\r\n\r\n      <ion-item color=\"\" slot=\"\" lines=\"none\">\r\n         <div class=\"fullDiv\">\r\n            <h5>Categories</h5>\r\n            <div>\r\n               <ion-text *ngFor=\"let category of categories\">\r\n                  <p class=\"category\">{{category.category}}</p>\r\n               </ion-text>\r\n            </div>\r\n            <!-- <ion-button size=\"small\" color=\"danger\" class=\"card-button\">Request category</ion-button> -->\r\n         </div>\r\n      </ion-item>\r\n     <!-- <app-explore-container name=\"Tab 1 page\"></app-explore-container> -->\r\n   </ion-content>\r\n</ion-app>\r\n");

/***/ }),

/***/ 8443:
/*!*************************************!*\
  !*** ./src/app/tab1/tab1.page.scss ***!
  \*************************************/
/***/ ((module) => {

module.exports = ".header-icon {\n  width: 40px;\n  height: 40px;\n  margin-bottom: 5px;\n}\n\n.bold {\n  font-size: 1.4em;\n  font-weight: bold;\n  letter-spacing: 1px;\n}\n\nion-toolbar {\n  padding-left: 20px;\n}\n\nion-item {\n  margin: 30px 15px;\n  margin-bottom: 40px;\n  --padding: 35px 10px;\n  --border-radius: 10px;\n}\n\nh3, h4, h5 {\n  text-align: center;\n  display: block;\n}\n\n.small {\n  font-size: 1.1em;\n  text-align: left;\n  padding-left: 15px;\n}\n\n.bolder {\n  font-size: 2.5em;\n  font-weight: bolder;\n  text-shadow: 0.5px 0.5px 1px #000;\n  line-height: 70px;\n  margin-top: 0px;\n  letter-spacing: 1px;\n}\n\n.fullDiv {\n  width: 100%;\n  height: 100%;\n  display: grid;\n  justify-items: center;\n}\n\n.card-button {\n  letter-spacing: 1px;\n  font-weight: bold;\n  margin-bottom: 10px;\n}\n\n.category {\n  padding: 10px;\n  letter-spacing: 1px;\n  text-align: center;\n  display: inline-flex;\n  margin: 5px 6px;\n  background: #5260ff;\n  border-radius: 30px;\n  color: white;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInRhYjEucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBRUcsV0FBQTtFQUNBLFlBQUE7RUFDQSxrQkFBQTtBQUFIOztBQUVBO0VBRUcsZ0JBQUE7RUFDQSxpQkFBQTtFQUNBLG1CQUFBO0FBQUg7O0FBRUE7RUFFRyxrQkFBQTtBQUFIOztBQUVBO0VBRUcsaUJBQUE7RUFDQSxtQkFBQTtFQUNBLG9CQUFBO0VBQ0EscUJBQUE7QUFBSDs7QUFFQTtFQUVHLGtCQUFBO0VBQ0EsY0FBQTtBQUFIOztBQUVBO0VBRUcsZ0JBQUE7RUFDQSxnQkFBQTtFQUNBLGtCQUFBO0FBQUg7O0FBRUE7RUFFRyxnQkFBQTtFQUNBLG1CQUFBO0VBQ0EsaUNBQUE7RUFDQSxpQkFBQTtFQUNBLGVBQUE7RUFDQSxtQkFBQTtBQUFIOztBQUVBO0VBRUcsV0FBQTtFQUNBLFlBQUE7RUFDQSxhQUFBO0VBQ0EscUJBQUE7QUFBSDs7QUFFQTtFQUVHLG1CQUFBO0VBQ0EsaUJBQUE7RUFDQSxtQkFBQTtBQUFIOztBQUVBO0VBRUcsYUFBQTtFQUNBLG1CQUFBO0VBQ0Esa0JBQUE7RUFDQSxvQkFBQTtFQUNBLGVBQUE7RUFDQSxtQkFBQTtFQUNBLG1CQUFBO0VBQ0EsWUFBQTtBQUFIIiwiZmlsZSI6InRhYjEucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmhlYWRlci1pY29uXHJcbntcclxuICAgd2lkdGg6IDQwcHg7XHJcbiAgIGhlaWdodDo0MHB4O1xyXG4gICBtYXJnaW4tYm90dG9tOiA1cHg7XHJcbn1cclxuLmJvbGRcclxue1xyXG4gICBmb250LXNpemU6IDEuNGVtO1xyXG4gICBmb250LXdlaWdodDogYm9sZDtcclxuICAgbGV0dGVyLXNwYWNpbmc6IDFweDtcclxufVxyXG5pb24tdG9vbGJhclxyXG57XHJcbiAgIHBhZGRpbmctbGVmdDogMjBweDtcclxufVxyXG5pb24taXRlbVxyXG57XHJcbiAgIG1hcmdpbjogMzBweCAxNXB4O1xyXG4gICBtYXJnaW4tYm90dG9tOiA0MHB4O1xyXG4gICAtLXBhZGRpbmc6IDM1cHggMTBweDtcclxuICAgLS1ib3JkZXItcmFkaXVzOiAxMHB4O1xyXG59XHJcbmgzLCBoNCwgaDVcclxue1xyXG4gICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgIGRpc3BsYXk6IGJsb2NrO1xyXG59XHJcbi5zbWFsbFxyXG57XHJcbiAgIGZvbnQtc2l6ZTogMS4xZW07XHJcbiAgIHRleHQtYWxpZ246IGxlZnQ7XHJcbiAgIHBhZGRpbmctbGVmdDogMTVweDtcclxufVxyXG4uYm9sZGVyXHJcbntcclxuICAgZm9udC1zaXplOiAyLjVlbTtcclxuICAgZm9udC13ZWlnaHQ6IGJvbGRlcjtcclxuICAgdGV4dC1zaGFkb3c6IDAuNXB4IC41cHggMXB4ICMwMDA7XHJcbiAgIGxpbmUtaGVpZ2h0OiA3MHB4O1xyXG4gICBtYXJnaW4tdG9wOiAwcHg7XHJcbiAgIGxldHRlci1zcGFjaW5nOiAxcHg7XHJcbn1cclxuLmZ1bGxEaXZcclxue1xyXG4gICB3aWR0aDogMTAwJTtcclxuICAgaGVpZ2h0OiAxMDAlO1xyXG4gICBkaXNwbGF5OiBncmlkO1xyXG4gICBqdXN0aWZ5LWl0ZW1zOiBjZW50ZXI7XHJcbn1cclxuLmNhcmQtYnV0dG9uXHJcbntcclxuICAgbGV0dGVyLXNwYWNpbmc6IDFweDtcclxuICAgZm9udC13ZWlnaHQ6IGJvbGQ7XHJcbiAgIG1hcmdpbi1ib3R0b206IDEwcHg7XHJcbn1cclxuLmNhdGVnb3J5XHJcbntcclxuICAgcGFkZGluZzogMTBweDtcclxuICAgbGV0dGVyLXNwYWNpbmc6IDFweDtcclxuICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICBkaXNwbGF5OiBpbmxpbmUtZmxleDtcclxuICAgbWFyZ2luOiA1cHggNnB4O1xyXG4gICBiYWNrZ3JvdW5kOiAjNTI2MGZmO1xyXG4gICBib3JkZXItcmFkaXVzOiAzMHB4O1xyXG4gICBjb2xvcjogd2hpdGU7XHJcbn1cclxuIl19 */";

/***/ })

}]);
//# sourceMappingURL=src_app_tab1_tab1_module_ts.js.map