"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_create-income_create-income_module_ts"],{

/***/ 253:
/*!***************************************************************!*\
  !*** ./src/app/create-income/create-income-routing.module.ts ***!
  \***************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CreateIncomePageRoutingModule": () => (/* binding */ CreateIncomePageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 8806);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 4001);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 3252);
/* harmony import */ var _create_income_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./create-income.page */ 5423);




const routes = [
    {
        path: '',
        component: _create_income_page__WEBPACK_IMPORTED_MODULE_0__.CreateIncomePage
    }
];
let CreateIncomePageRoutingModule = class CreateIncomePageRoutingModule {
};
CreateIncomePageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], CreateIncomePageRoutingModule);



/***/ }),

/***/ 7691:
/*!*******************************************************!*\
  !*** ./src/app/create-income/create-income.module.ts ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CreateIncomePageModule": () => (/* binding */ CreateIncomePageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 8806);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 4001);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 8267);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 8346);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 8099);
/* harmony import */ var _create_income_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./create-income-routing.module */ 253);
/* harmony import */ var _create_income_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./create-income.page */ 5423);







let CreateIncomePageModule = class CreateIncomePageModule {
};
CreateIncomePageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _create_income_routing_module__WEBPACK_IMPORTED_MODULE_0__.CreateIncomePageRoutingModule
        ],
        declarations: [_create_income_page__WEBPACK_IMPORTED_MODULE_1__.CreateIncomePage]
    })
], CreateIncomePageModule);



/***/ }),

/***/ 5423:
/*!*****************************************************!*\
  !*** ./src/app/create-income/create-income.page.ts ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CreateIncomePage": () => (/* binding */ CreateIncomePage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 8806);
/* harmony import */ var _C_wamp64_www_financeApp_node_modules_ngtools_webpack_src_loaders_direct_resource_js_create_income_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !./node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./create-income.page.html */ 1018);
/* harmony import */ var _create_income_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./create-income.page.scss */ 2517);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 4001);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ 8099);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ 3252);
/* harmony import */ var _Service_income_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../Service/income.service */ 6017);







let CreateIncomePage = class CreateIncomePage {
    constructor(toastCtrl, loadingctrl, router, revenue) {
        this.toastCtrl = toastCtrl;
        this.loadingctrl = loadingctrl;
        this.router = router;
        this.revenue = revenue;
        this.user = JSON.parse(localStorage.getItem("user"));
        this.income = { amount: '', user_id: this.user.user_id, source: '' };
    }
    ionViewWillEnter() {
        this.getAvailableIncomeSources();
    }
    addIncome() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(this, void 0, void 0, function* () {
            yield this.presentLoading("Adding expense....");
            let checked = this.validateData(this.income);
            if (checked) {
                this.loadingctrl.dismiss();
                this.presentToast(checked);
            }
            else {
                this.revenue.addIncome(this.income, localStorage.getItem("token")).subscribe(response => {
                    let information = (typeof response == 'object') ? response : JSON.parse(response);
                    if (information.status == 0) {
                        this.loadingctrl.dismiss();
                        this.presentToast(information.message);
                    }
                    else if (information.status == 1) {
                        this.loadingctrl.dismiss();
                        this.presentToast(information.message);
                        this.income.amount = '';
                    }
                    else {
                        this.loadingctrl.dismiss();
                        this.presentToast(information.message);
                    }
                }, error => {
                    console.log(error);
                });
            }
        });
    }
    back() {
        this.router.navigate(['/tabs/tab1']);
    }
    presentLoading(message) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(this, void 0, void 0, function* () {
            const loading = yield this.loadingctrl.create({
                cssClass: 'my-custom-class',
                message: message,
                spinner: "lines-sharp",
                backdropDismiss: true,
                id: 'loader'
            });
            yield loading.present();
        });
    }
    presentToast(message, time = 4000, type = "dark") {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(this, void 0, void 0, function* () {
            const toast = yield this.toastCtrl.create({
                message: message,
                position: "bottom",
                color: type,
                duration: time
            });
            toast.present();
        });
    }
    validateData(data) {
        for (let [key, value] of Object.entries(data)) {
            if (value == undefined || value == null || value.length < 2) {
                return key + " is Invalid";
            }
        }
    }
    getAvailableIncomeSources() {
        this.revenue.getSources(localStorage.getItem("token")).subscribe(response => {
            this.sources = response.data;
            console.log(this.sources);
        }, error => {
            console.log(error);
        });
    }
};
CreateIncomePage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.ToastController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.LoadingController },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_5__.Router },
    { type: _Service_income_service__WEBPACK_IMPORTED_MODULE_2__.IncomeService }
];
CreateIncomePage = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_6__.Component)({
        selector: 'app-create-income',
        template: _C_wamp64_www_financeApp_node_modules_ngtools_webpack_src_loaders_direct_resource_js_create_income_page_html__WEBPACK_IMPORTED_MODULE_0__["default"],
        styles: [_create_income_page_scss__WEBPACK_IMPORTED_MODULE_1__]
    })
], CreateIncomePage);



/***/ }),

/***/ 1018:
/*!**********************************************************************************************************************!*\
  !*** ./node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./src/app/create-income/create-income.page.html ***!
  \**********************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-app>\r\n   <ion-fab vertical=\"top\" horizontal=\"start\" slot=\"fixed\">\r\n     <ion-fab-button color=\"tertiary\" (click)=\"back()\">\r\n        <ion-icon name=\"arrow-back-outline\"></ion-icon>\r\n     </ion-fab-button>\r\n   </ion-fab>\r\n   <!-- <ion-header class=\"header ion-no-border\" color=\"primary\">\r\n      <ion-img src=\"../../assets/income.svg\"></ion-img>\r\n   </ion-header> -->\r\n   <ion-content>\r\n      <div class=\"header ion-no-border\" color=\"primary\">\r\n         <ion-img src=\"../../assets/income.svg\"></ion-img>\r\n      </div>\r\n      <div class=\"container\">\r\n         <ion-text class=\"bold\"  color=\"tertiary\">Create Income</ion-text>\r\n         <ion-text color=\"\"><p>Agbafiriyoyo, Money boss...</p></ion-text>\r\n         <ion-item lines=\"none\" class=\"border\">\r\n             <ion-label position=\"floating\" >Sources</ion-label>\r\n             <ion-select [(ngModel)]=\"income.source\">\r\n                <ion-select-option *ngFor=\"let source of sources\" :value=\"{{source.source}}\" >{{source.source}}</ion-select-option>\r\n            </ion-select>\r\n         </ion-item>\r\n         <ion-item lines=\"none\" class=\"border\">\r\n           <ion-label position=\"floating\">Amount</ion-label>\r\n           <ion-input placeholder=\"Amount\" type=\"text\" [(ngModel)]=\"income.amount\"></ion-input>\r\n         </ion-item>\r\n         <div>\r\n            <ion-button size=\"default\" expand=\"block\" color=\"tertiary\" (click)=\"addIncome()\">Create Income</ion-button>\r\n         </div>\r\n\r\n      </div>\r\n   </ion-content>\r\n</ion-app>\r\n");

/***/ }),

/***/ 2517:
/*!*******************************************************!*\
  !*** ./src/app/create-income/create-income.page.scss ***!
  \*******************************************************/
/***/ ((module) => {

module.exports = ".header {\n  display: flex;\n  justify-content: center;\n  align-items: center;\n  width: 100vw;\n}\n\nion-img {\n  height: 300px;\n  width: 60vw;\n  margin-top: 20px;\n}\n\n.container {\n  padding: 30px;\n  margin-top: 30px;\n}\n\n.border {\n  border: solid thin #000;\n  border-radius: 20px;\n}\n\nion-item {\n  margin-top: 50px;\n}\n\n.grid {\n  display: grid;\n}\n\n.bold {\n  font-weight: bolder;\n  text-align: left;\n  margin-bottom: 30px;\n  line-height: 40px;\n  font-size: 1.3em;\n  text-shadow: 0.5px 0.5px 1px #000000;\n}\n\n.border {\n  border: solid thin #000;\n  margin: 10px auto;\n}\n\nion-label {\n  font-size: 1.8em;\n  letter-spacing: 1px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImNyZWF0ZS1pbmNvbWUucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBRUcsYUFBQTtFQUNBLHVCQUFBO0VBQ0EsbUJBQUE7RUFDQSxZQUFBO0FBQUg7O0FBRUE7RUFFRyxhQUFBO0VBQ0EsV0FBQTtFQUNBLGdCQUFBO0FBQUg7O0FBRUE7RUFFRyxhQUFBO0VBQ0EsZ0JBQUE7QUFBSDs7QUFFQTtFQUVHLHVCQUFBO0VBQ0EsbUJBQUE7QUFBSDs7QUFHQTtFQUVHLGdCQUFBO0FBREg7O0FBR0E7RUFDRyxhQUFBO0FBQUg7O0FBRUE7RUFFRyxtQkFBQTtFQUNBLGdCQUFBO0VBQ0EsbUJBQUE7RUFDQSxpQkFBQTtFQUNBLGdCQUFBO0VBQ0Msb0NBQUE7QUFBSjs7QUFFQTtFQUVHLHVCQUFBO0VBQ0EsaUJBQUE7QUFBSDs7QUFFQTtFQUVHLGdCQUFBO0VBQ0EsbUJBQUE7QUFBSCIsImZpbGUiOiJjcmVhdGUtaW5jb21lLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5oZWFkZXJcclxue1xyXG4gICBkaXNwbGF5OiBmbGV4O1xyXG4gICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICAgd2lkdGg6IDEwMHZ3O1xyXG59XHJcbmlvbi1pbWdcclxue1xyXG4gICBoZWlnaHQ6IDMwMHB4O1xyXG4gICB3aWR0aDogNjB2dztcclxuICAgbWFyZ2luLXRvcDogMjBweDtcclxufVxyXG4uY29udGFpbmVyXHJcbntcclxuICAgcGFkZGluZzogMzBweDtcclxuICAgbWFyZ2luLXRvcDogMzBweFxyXG59XHJcbi5ib3JkZXJcclxue1xyXG4gICBib3JkZXI6IHNvbGlkIHRoaW4gIzAwMDtcclxuICAgYm9yZGVyLXJhZGl1czogMjBweDtcclxuICAgLy8gbWFyZ2luOiAxMDBweCAwO1xyXG59XHJcbmlvbi1pdGVtXHJcbntcclxuICAgbWFyZ2luLXRvcDogNTBweFxyXG59XHJcbi5ncmlke1xyXG4gICBkaXNwbGF5OiBncmlkO1xyXG59XHJcbi5ib2xkXHJcbntcclxuICAgZm9udC13ZWlnaHQ6IGJvbGRlcjtcclxuICAgdGV4dC1hbGlnbjogbGVmdDtcclxuICAgbWFyZ2luLWJvdHRvbTogMzBweDtcclxuICAgbGluZS1oZWlnaHQ6IDQwcHg7XHJcbiAgIGZvbnQtc2l6ZTogMS4zZW07XHJcbiAgICB0ZXh0LXNoYWRvdzogLjVweCAuNXB4IDFweCAjMDAwMDAwO1xyXG59XHJcbi5ib3JkZXJcclxue1xyXG4gICBib3JkZXI6IHNvbGlkIHRoaW4gIzAwMDtcclxuICAgbWFyZ2luOiAxMHB4IGF1dG87XHJcbn1cclxuaW9uLWxhYmVsXHJcbntcclxuICAgZm9udC1zaXplOiAxLjhlbTtcclxuICAgbGV0dGVyLXNwYWNpbmc6IDFweDtcclxufVxyXG4iXX0= */";

/***/ })

}]);
//# sourceMappingURL=src_app_create-income_create-income_module_ts.js.map