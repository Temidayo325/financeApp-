# financeApp-
An app to observe all my expenses
The app is made to record my expenses and incomes and where where my money is going for proper budgetiing and planning
