"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_tab3_tab3_module_ts"],{

/***/ 8058:
/*!*********************************************!*\
  !*** ./src/app/tab3/tab3-routing.module.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Tab3PageRoutingModule": () => (/* binding */ Tab3PageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 8806);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 4001);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 3252);
/* harmony import */ var _tab3_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./tab3.page */ 2308);




const routes = [
    {
        path: '',
        component: _tab3_page__WEBPACK_IMPORTED_MODULE_0__.Tab3Page,
    }
];
let Tab3PageRoutingModule = class Tab3PageRoutingModule {
};
Tab3PageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule]
    })
], Tab3PageRoutingModule);



/***/ }),

/***/ 7586:
/*!*************************************!*\
  !*** ./src/app/tab3/tab3.module.ts ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Tab3PageModule": () => (/* binding */ Tab3PageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 8806);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ 8099);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/router */ 3252);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 4001);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/common */ 8267);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/forms */ 8346);
/* harmony import */ var _tab3_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./tab3.page */ 2308);
/* harmony import */ var _explore_container_explore_container_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../explore-container/explore-container.module */ 456);
/* harmony import */ var _tab3_routing_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./tab3-routing.module */ 8058);









let Tab3PageModule = class Tab3PageModule {
};
Tab3PageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.NgModule)({
        imports: [
            _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.IonicModule,
            _angular_common__WEBPACK_IMPORTED_MODULE_6__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_7__.FormsModule,
            _explore_container_explore_container_module__WEBPACK_IMPORTED_MODULE_1__.ExploreContainerComponentModule,
            _angular_router__WEBPACK_IMPORTED_MODULE_8__.RouterModule.forChild([{ path: '', component: _tab3_page__WEBPACK_IMPORTED_MODULE_0__.Tab3Page }]),
            _tab3_routing_module__WEBPACK_IMPORTED_MODULE_2__.Tab3PageRoutingModule,
        ],
        declarations: [_tab3_page__WEBPACK_IMPORTED_MODULE_0__.Tab3Page]
    })
], Tab3PageModule);



/***/ }),

/***/ 2308:
/*!***********************************!*\
  !*** ./src/app/tab3/tab3.page.ts ***!
  \***********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Tab3Page": () => (/* binding */ Tab3Page)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 8806);
/* harmony import */ var _C_wamp64_www_financeApp_node_modules_ngtools_webpack_src_loaders_direct_resource_js_tab3_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !./node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./tab3.page.html */ 8752);
/* harmony import */ var _tab3_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./tab3.page.scss */ 4170);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 4001);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ 3252);
/* harmony import */ var _Service_income_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../Service/income.service */ 6017);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ 8099);





// import { PersonService } from '../Service/person.service';


let Tab3Page = class Tab3Page {
    constructor(router, 
    // private person: PersonService,
    revenue, toastCtrl, loadingctrl) {
        this.router = router;
        this.revenue = revenue;
        this.toastCtrl = toastCtrl;
        this.loadingctrl = loadingctrl;
        this.total = "00.00";
    }
    ionViewWillEnter() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(this, void 0, void 0, function* () {
            yield this.presentLoading("Retrieving your expense....");
            const userData = JSON.parse(localStorage.getItem("user"));
            this.revenue.getRevenue(userData.user_id, localStorage.getItem("token")).subscribe(response => {
                let parsed = (typeof response == 'object') ? response : JSON.parse(response);
                console.log(parsed);
                this.presentToast(parsed.message);
                if (parsed.status == 0) {
                    this.loadingctrl.dismiss();
                    this.presentToast(parsed.message);
                    console.log(parsed);
                }
                else if (parsed.status == 1) {
                    this.loadingctrl.dismiss();
                    this.income = parsed.data;
                    this.total = parsed.total;
                    console.log(parsed);
                }
                else {
                    this.loadingctrl.dismiss();
                    this.presentToast("Unable to retrieve current Expenses");
                    console.log(parsed);
                }
            }, (error) => {
                console.log(error);
            });
        });
    }
    presentLoading(message) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(this, void 0, void 0, function* () {
            const loading = yield this.loadingctrl.create({
                cssClass: 'my-custom-class',
                message: message,
                spinner: "lines-sharp",
                backdropDismiss: true,
                id: 'loader'
            });
            yield loading.present();
        });
    }
    presentToast(message, time = 4000, type = "dark") {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(this, void 0, void 0, function* () {
            const toast = yield this.toastCtrl.create({
                message: message,
                position: "bottom",
                color: type,
                duration: time
            });
            toast.present();
        });
    }
    addIncome() {
        this.router.navigate(['/create-income']);
    }
};
Tab3Page.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__.Router },
    { type: _Service_income_service__WEBPACK_IMPORTED_MODULE_2__.IncomeService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.ToastController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.LoadingController }
];
Tab3Page = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_6__.Component)({
        selector: 'app-tab3',
        template: _C_wamp64_www_financeApp_node_modules_ngtools_webpack_src_loaders_direct_resource_js_tab3_page_html__WEBPACK_IMPORTED_MODULE_0__["default"],
        styles: [_tab3_page_scss__WEBPACK_IMPORTED_MODULE_1__]
    })
], Tab3Page);



/***/ }),

/***/ 8752:
/*!****************************************************************************************************!*\
  !*** ./node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./src/app/tab3/tab3.page.html ***!
  \****************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-app>\r\n  <ion-fab slot=\"fixed\" vertical=\"top\" horizontal=\"end\">\r\n    <ion-fab-button color=\"light\" (click)=\"addIncome()\">\r\n      <ion-icon name=\"add-outline\"></ion-icon>\r\n    </ion-fab-button>\r\n  </ion-fab>\r\n  <ion-header color=\"\" class=\"header ion-no-border\" style=\"clip-path: ellipse(117% 100% at 52.01% 0%);\">\r\n    <div class=\"header-container\">\r\n      <ion-text>\r\n        <h5>Income</h5>\r\n      </ion-text>\r\n      <ion-text class=\"bolder\">\r\n        <h1>#{{total}}</h1>\r\n      </ion-text>\r\n    </div>\r\n  </ion-header>\r\n  <ion-content fullscreen=\"true\">\r\n    <div *ngIf=\"total !== 0\">\r\n      <ion-item color=\"primary\" *ngFor=\"let revenue of income\">\r\n        <div class=\"fullDiv\">\r\n          <div class=\"flex\">\r\n            <ion-text class=\"\">Date: {{revenue.created_at}}</ion-text>\r\n          </div>\r\n          <div class=\"center\">\r\n            <ion-text color=\"tertiary\">\r\n              <h1 class=\"bold\">#{{revenue.amount}}</h1>\r\n            </ion-text>\r\n          </div>\r\n          <div class=\"flex\">\r\n            <ion-text class=\"\">Source: </ion-text>\r\n            <ion-text class=\"\">{{income.source}}</ion-text>\r\n          </div>\r\n        </div>\r\n      </ion-item>\r\n    </div>\r\n    <div *ngIf=\"total == 0\" class=\"no-expenses-wrapper\">\r\n      <div class=\"no-expenses\">\r\n        <ion-text>\r\n          <p>You have not recorded any Income yet. Click the button below to record an Income</p>\r\n        </ion-text>\r\n        <ion-button size=\"default\" expand=\"block\" color=\"tertiary\" (click)=\"addIncome()\">Add Income</ion-button>\r\n      </div>\r\n    </div>\r\n  </ion-content>\r\n</ion-app>\r\n");

/***/ }),

/***/ 4170:
/*!*************************************!*\
  !*** ./src/app/tab3/tab3.page.scss ***!
  \*************************************/
/***/ ((module) => {

module.exports = ".header {\n  display: grid;\n  justify-content: center;\n  align-items: center;\n  background: #004481;\n  width: 100vw;\n  height: 15vh;\n}\n\n.header-container {\n  text-align: center;\n}\n\n.bolder {\n  font-size: 4em;\n  color: white;\n  font-weight: bolder;\n  text-shadow: 0.5px 0.5px 1px #000;\n  line-height: 70px;\n  margin-top: 0px;\n  letter-spacing: 1px;\n}\n\nh5 {\n  font-size: 1em;\n  color: white;\n}\n\n.bold {\n  font-size: 1.7em;\n  font-weight: bolder;\n  text-shadow: 0.5px 0.5px 1px #000;\n  margin-top: 0px;\n  letter-spacing: 1px;\n  color: white;\n}\n\nion-item {\n  margin: 30px auto;\n  width: 90vw;\n  padding: 15px 0;\n  --border-radius: 10px ;\n}\n\nion-text {\n  letter-spacing: 1px;\n}\n\n.flex {\n  padding: 10px 0;\n}\n\n.fullDiv {\n  width: 100%;\n  height: 100%;\n}\n\n.center {\n  display: grid;\n  justify-content: center;\n  text-align: center;\n}\n\n.no-expenses-wrapper {\n  display: flex;\n  justify-content: center;\n}\n\n.no-expenses {\n  line-height: 25px;\n  letter-spacing: 1px;\n  width: 80vw;\n  margin-top: 23vh;\n}\n\nion-button {\n  margin-top: 15px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInRhYjMucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBRUcsYUFBQTtFQUNBLHVCQUFBO0VBQ0EsbUJBQUE7RUFDQSxtQkFBQTtFQUNBLFlBQUE7RUFDQSxZQUFBO0FBQUg7O0FBRUE7RUFFRyxrQkFBQTtBQUFIOztBQUVBO0VBRUcsY0FBQTtFQUNBLFlBQUE7RUFDQSxtQkFBQTtFQUNBLGlDQUFBO0VBQ0EsaUJBQUE7RUFDQSxlQUFBO0VBQ0EsbUJBQUE7QUFBSDs7QUFFQTtFQUVHLGNBQUE7RUFDQSxZQUFBO0FBQUg7O0FBRUE7RUFFRyxnQkFBQTtFQUNBLG1CQUFBO0VBQ0EsaUNBQUE7RUFDQSxlQUFBO0VBQ0EsbUJBQUE7RUFDQSxZQUFBO0FBQUg7O0FBRUE7RUFFRyxpQkFBQTtFQUNBLFdBQUE7RUFDQSxlQUFBO0VBQ0Esc0JBQUE7QUFBSDs7QUFFQTtFQUVHLG1CQUFBO0FBQUg7O0FBRUE7RUFFRyxlQUFBO0FBQUg7O0FBRUE7RUFFRyxXQUFBO0VBQ0EsWUFBQTtBQUFIOztBQUVBO0VBRUcsYUFBQTtFQUNBLHVCQUFBO0VBQ0Esa0JBQUE7QUFBSDs7QUFFQTtFQUVLLGFBQUE7RUFDQSx1QkFBQTtBQUFMOztBQUVBO0VBRUssaUJBQUE7RUFDQSxtQkFBQTtFQUNBLFdBQUE7RUFDQSxnQkFBQTtBQUFMOztBQUVBO0VBRUssZ0JBQUE7QUFBTCIsImZpbGUiOiJ0YWIzLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5oZWFkZXJcclxue1xyXG4gICBkaXNwbGF5OiBncmlkO1xyXG4gICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICAgYmFja2dyb3VuZDogIzAwNDQ4MTtcclxuICAgd2lkdGg6IDEwMHZ3O1xyXG4gICBoZWlnaHQ6IDE1dmg7XHJcbn1cclxuLmhlYWRlci1jb250YWluZXJcclxue1xyXG4gICB0ZXh0LWFsaWduOiBjZW50ZXJcclxufVxyXG4uYm9sZGVyXHJcbntcclxuICAgZm9udC1zaXplOiA0ZW07XHJcbiAgIGNvbG9yOiB3aGl0ZTtcclxuICAgZm9udC13ZWlnaHQ6IGJvbGRlcjtcclxuICAgdGV4dC1zaGFkb3c6IDAuNXB4IC41cHggMXB4ICMwMDA7XHJcbiAgIGxpbmUtaGVpZ2h0OiA3MHB4O1xyXG4gICBtYXJnaW4tdG9wOiAwcHg7XHJcbiAgIGxldHRlci1zcGFjaW5nOiAxcHg7XHJcbn1cclxuaDVcclxue1xyXG4gICBmb250LXNpemU6IDFlbTtcclxuICAgY29sb3I6IHdoaXRlO1xyXG59XHJcbi5ib2xkXHJcbntcclxuICAgZm9udC1zaXplOiAxLjdlbTtcclxuICAgZm9udC13ZWlnaHQ6IGJvbGRlcjtcclxuICAgdGV4dC1zaGFkb3c6IDAuNXB4IC41cHggMXB4ICMwMDA7XHJcbiAgIG1hcmdpbi10b3A6IDBweDtcclxuICAgbGV0dGVyLXNwYWNpbmc6IDFweDtcclxuICAgY29sb3I6IHdoaXRlO1xyXG59XHJcbmlvbi1pdGVtXHJcbntcclxuICAgbWFyZ2luOiAzMHB4IGF1dG87XHJcbiAgIHdpZHRoOiA5MHZ3O1xyXG4gICBwYWRkaW5nOiAxNXB4IDA7XHJcbiAgIC0tYm9yZGVyLXJhZGl1czogMTBweFxyXG59XHJcbmlvbi10ZXh0XHJcbntcclxuICAgbGV0dGVyLXNwYWNpbmc6IDFweDtcclxufVxyXG4uZmxleFxyXG57XHJcbiAgIHBhZGRpbmc6IDEwcHggMDtcclxufVxyXG4uZnVsbERpdlxyXG57XHJcbiAgIHdpZHRoOiAxMDAlO1xyXG4gICBoZWlnaHQ6MTAwJTtcclxufVxyXG4uY2VudGVyXHJcbntcclxuICAgZGlzcGxheTogZ3JpZDtcclxuICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxufVxyXG4ubm8tZXhwZW5zZXMtd3JhcHBlclxyXG57XHJcbiAgICAgZGlzcGxheTogZmxleDtcclxuICAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxufVxyXG4ubm8tZXhwZW5zZXNcclxue1xyXG4gICAgIGxpbmUtaGVpZ2h0OiAyNXB4O1xyXG4gICAgIGxldHRlci1zcGFjaW5nOiAxcHg7XHJcbiAgICAgd2lkdGg6IDgwdnc7XHJcbiAgICAgbWFyZ2luLXRvcDogMjN2aDtcclxufVxyXG5pb24tYnV0dG9uXHJcbntcclxuICAgICBtYXJnaW4tdG9wOiAxNXB4O1xyXG59XHJcbiJdfQ== */";

/***/ })

}]);
//# sourceMappingURL=src_app_tab3_tab3_module_ts.js.map