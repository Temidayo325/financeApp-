"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_create-expense_create-expense_module_ts"],{

/***/ 6533:
/*!*****************************************************************!*\
  !*** ./src/app/create-expense/create-expense-routing.module.ts ***!
  \*****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CreateExpensePageRoutingModule": () => (/* binding */ CreateExpensePageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 8806);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 4001);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 3252);
/* harmony import */ var _create_expense_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./create-expense.page */ 1799);




const routes = [
    {
        path: '',
        component: _create_expense_page__WEBPACK_IMPORTED_MODULE_0__.CreateExpensePage
    }
];
let CreateExpensePageRoutingModule = class CreateExpensePageRoutingModule {
};
CreateExpensePageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], CreateExpensePageRoutingModule);



/***/ }),

/***/ 4398:
/*!*********************************************************!*\
  !*** ./src/app/create-expense/create-expense.module.ts ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CreateExpensePageModule": () => (/* binding */ CreateExpensePageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 8806);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 4001);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 8267);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 8346);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 8099);
/* harmony import */ var _create_expense_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./create-expense-routing.module */ 6533);
/* harmony import */ var _create_expense_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./create-expense.page */ 1799);







let CreateExpensePageModule = class CreateExpensePageModule {
};
CreateExpensePageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _create_expense_routing_module__WEBPACK_IMPORTED_MODULE_0__.CreateExpensePageRoutingModule
        ],
        declarations: [_create_expense_page__WEBPACK_IMPORTED_MODULE_1__.CreateExpensePage]
    })
], CreateExpensePageModule);



/***/ }),

/***/ 1799:
/*!*******************************************************!*\
  !*** ./src/app/create-expense/create-expense.page.ts ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CreateExpensePage": () => (/* binding */ CreateExpensePage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 8806);
/* harmony import */ var _C_wamp64_www_financeApp_node_modules_ngtools_webpack_src_loaders_direct_resource_js_create_expense_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !./node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./create-expense.page.html */ 6620);
/* harmony import */ var _create_expense_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./create-expense.page.scss */ 5459);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 4001);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ 8099);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ 3252);
/* harmony import */ var _Service_expense_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../Service/expense.service */ 4709);







// import { InformationService } from '../Service/information.service';
let CreateExpensePage = class CreateExpensePage {
    constructor(toastCtrl, loadingctrl, router, expenses) {
        this.toastCtrl = toastCtrl;
        this.loadingctrl = loadingctrl;
        this.router = router;
        this.expenses = expenses;
        this.user = JSON.parse(localStorage.getItem("user"));
        this.expense = { category: '', amount: '', user_id: this.user.user_id, description: '' };
        this.categories = JSON.parse(localStorage.getItem("categories"));
    }
    ionViewWillEnter() {
    }
    addExpense() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(this, void 0, void 0, function* () {
            yield this.presentLoading("Adding expense....");
            let checked = this.validateData(this.expense);
            if (checked) {
                this.loadingctrl.dismiss();
                this.presentToast(checked);
            }
            else {
                this.expenses.addExpense(this.expense, localStorage.getItem("token")).subscribe(response => {
                    console.log(response);
                    let information = (typeof response == 'object') ? response : JSON.parse(response);
                    if (information.status == 0) {
                        this.loadingctrl.dismiss();
                        this.presentToast(information.message);
                    }
                    else if (information.status == 1) {
                        this.loadingctrl.dismiss();
                        this.presentToast("Expense recorded successfully");
                        this.expense.amount = '';
                        this.expense.category = '';
                    }
                    else {
                        this.loadingctrl.dismiss();
                        this.presentToast(information.message);
                    }
                }, error => {
                    console.log(error);
                });
            }
        });
    }
    back() {
        this.router.navigate(['/tabs/tab1']);
    }
    presentLoading(message) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(this, void 0, void 0, function* () {
            const loading = yield this.loadingctrl.create({
                cssClass: 'my-custom-class',
                message: message,
                spinner: "lines-sharp",
                backdropDismiss: true,
                id: 'loader'
            });
            yield loading.present();
        });
    }
    presentToast(message, time = 4000, type = "dark") {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(this, void 0, void 0, function* () {
            const toast = yield this.toastCtrl.create({
                message: message,
                position: "bottom",
                color: type,
                duration: time
            });
            toast.present();
        });
    }
    validateData(data) {
        for (let [key, value] of Object.entries(data)) {
            if (value == undefined || value == null || value.length < 2) {
                return key + " is Invalid";
            }
        }
    }
};
CreateExpensePage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.ToastController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.LoadingController },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_5__.Router },
    { type: _Service_expense_service__WEBPACK_IMPORTED_MODULE_2__.ExpenseService }
];
CreateExpensePage = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_6__.Component)({
        selector: 'app-create-expense',
        template: _C_wamp64_www_financeApp_node_modules_ngtools_webpack_src_loaders_direct_resource_js_create_expense_page_html__WEBPACK_IMPORTED_MODULE_0__["default"],
        styles: [_create_expense_page_scss__WEBPACK_IMPORTED_MODULE_1__]
    })
], CreateExpensePage);



/***/ }),

/***/ 6620:
/*!************************************************************************************************************************!*\
  !*** ./node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./src/app/create-expense/create-expense.page.html ***!
  \************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-app>\r\n   <ion-fab vertical=\"top\" horizontal=\"start\" slot=\"fixed\">\r\n     <ion-fab-button color=\"primary\" (click)=\"back()\">\r\n        <ion-icon name=\"arrow-back-outline\"></ion-icon>\r\n     </ion-fab-button>\r\n   </ion-fab>\r\n   <!-- <ion-header class=\"header ion-no-border\" color=\"primary\">\r\n      <ion-img src=\"../../assets/expense.svg\"></ion-img>\r\n   </ion-header> -->\r\n\r\n   <ion-content>\r\n      <div class=\"header ion-no-border\" color=\"primary\">\r\n         <ion-img src=\"../../assets/expense.svg\"></ion-img>\r\n      </div>\r\n      <div class=\"container\">\r\n         <ion-text class=\"bold\"  color=\"tertiary\">Create Expense</ion-text>\r\n         <p>Sorry boss, money has wings man..</p>\r\n         <ion-item lines=\"none\" class=\"border\">\r\n             <ion-label position=\"floating\" >Category</ion-label>\r\n             <ion-select [(ngModel)]=\"expense.category\">\r\n                <ion-select-option *ngFor=\"let category of categories\" :value=\"{{category.category}}\" >{{category.category}}</ion-select-option>\r\n            </ion-select>\r\n         </ion-item>\r\n         <ion-item lines=\"none\" class=\"border\">\r\n           <ion-label position=\"floating\">Amount</ion-label>\r\n           <ion-input placeholder=\"Amount\" type=\"text\" [(ngModel)]=\"expense.amount\"></ion-input>\r\n         </ion-item>\r\n         <ion-item lines=\"none\" class=\"border\">\r\n           <ion-label position=\"floating\">Add Description</ion-label>\r\n           <ion-input placeholder=\"Description\" type=\"text\" [(ngModel)]=\"expense.description\"></ion-input>\r\n         </ion-item>\r\n         <div>\r\n            <ion-button size=\"default\" expand=\"block\" color=\"tertiary\" (click)=\"addExpense()\">Create Expense</ion-button>\r\n         </div>\r\n\r\n      </div>\r\n   </ion-content>\r\n</ion-app>\r\n");

/***/ }),

/***/ 5459:
/*!*********************************************************!*\
  !*** ./src/app/create-expense/create-expense.page.scss ***!
  \*********************************************************/
/***/ ((module) => {

module.exports = ".header {\n  width: 100vw;\n  display: flex;\n  justify-content: center;\n  align-items: center;\n}\n\nion-img {\n  height: 300px;\n  width: 60vw;\n  margin-top: 20px;\n}\n\n.container {\n  padding: 30px;\n}\n\n.border {\n  border: solid thin #000;\n  border-radius: 20px;\n  margin: 70px 0;\n}\n\n.grid {\n  display: grid;\n}\n\n.bold {\n  font-weight: bolder;\n  text-align: left;\n  margin-bottom: 30px;\n  line-height: 40px;\n  font-size: 1.3em;\n  text-shadow: 0.5px 0.5px 1px #000000;\n}\n\n.border {\n  border: solid thin #000;\n  margin: 10px auto;\n}\n\nion-label {\n  font-size: 1.8em;\n  letter-spacing: 1px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImNyZWF0ZS1leHBlbnNlLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUVHLFlBQUE7RUFDQSxhQUFBO0VBQ0EsdUJBQUE7RUFDQSxtQkFBQTtBQUFIOztBQUVBO0VBRUcsYUFBQTtFQUNBLFdBQUE7RUFDQSxnQkFBQTtBQUFIOztBQUVBO0VBRUcsYUFBQTtBQUFIOztBQUVBO0VBRUcsdUJBQUE7RUFDQSxtQkFBQTtFQUNBLGNBQUE7QUFBSDs7QUFFQTtFQUNHLGFBQUE7QUFDSDs7QUFDQTtFQUVHLG1CQUFBO0VBQ0EsZ0JBQUE7RUFDQSxtQkFBQTtFQUNBLGlCQUFBO0VBQ0EsZ0JBQUE7RUFDQyxvQ0FBQTtBQUNKOztBQUNBO0VBRUcsdUJBQUE7RUFDQSxpQkFBQTtBQUNIOztBQUNBO0VBRUcsZ0JBQUE7RUFDQSxtQkFBQTtBQUNIIiwiZmlsZSI6ImNyZWF0ZS1leHBlbnNlLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5oZWFkZXJcclxue1xyXG4gICB3aWR0aDogMTAwdnc7XHJcbiAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gICBhbGlnbi1pdGVtczpjZW50ZXI7XHJcbn1cclxuaW9uLWltZ1xyXG57XHJcbiAgIGhlaWdodDogMzAwcHg7XHJcbiAgIHdpZHRoOiA2MHZ3O1xyXG4gICBtYXJnaW4tdG9wOiAyMHB4O1xyXG59XHJcbi5jb250YWluZXJcclxue1xyXG4gICBwYWRkaW5nOiAzMHB4O1xyXG59XHJcbi5ib3JkZXJcclxue1xyXG4gICBib3JkZXI6IHNvbGlkIHRoaW4gIzAwMDtcclxuICAgYm9yZGVyLXJhZGl1czogMjBweDtcclxuICAgbWFyZ2luOiA3MHB4IDA7XHJcbn1cclxuLmdyaWR7XHJcbiAgIGRpc3BsYXk6IGdyaWQ7XHJcbn1cclxuLmJvbGRcclxue1xyXG4gICBmb250LXdlaWdodDogYm9sZGVyO1xyXG4gICB0ZXh0LWFsaWduOiBsZWZ0O1xyXG4gICBtYXJnaW4tYm90dG9tOiAzMHB4O1xyXG4gICBsaW5lLWhlaWdodDogNDBweDtcclxuICAgZm9udC1zaXplOiAxLjNlbTtcclxuICAgIHRleHQtc2hhZG93OiAuNXB4IC41cHggMXB4ICMwMDAwMDA7XHJcbn1cclxuLmJvcmRlclxyXG57XHJcbiAgIGJvcmRlcjogc29saWQgdGhpbiAjMDAwO1xyXG4gICBtYXJnaW46IDEwcHggYXV0bztcclxufVxyXG5pb24tbGFiZWxcclxue1xyXG4gICBmb250LXNpemU6IDEuOGVtO1xyXG4gICBsZXR0ZXItc3BhY2luZzogMXB4O1xyXG59XHJcbiJdfQ== */";

/***/ })

}]);
//# sourceMappingURL=src_app_create-expense_create-expense_module_ts.js.map