import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { ExpenseService } from '../Service/expense.service';
import { InformationService } from '../Service/information.service';
import { ToastController, LoadingController  } from '@ionic/angular';

@Component({
  selector: 'app-change-password',
  templateUrl: './change-password.page.html',
  styleUrls: ['./change-password.page.scss'],
})
export class ChangePasswordPage  {

  constructor(
    private router: Router,
     private info: InformationService,
     private expense: ExpenseService,
     private toastCtrl: ToastController,
     public loadingctrl: LoadingController
  ) { }

 async ionViewWillEnter()
 {

 }
 back()
 {
  
 }
 requestCode()
 {

 }
 async presentLoading(message)
  {
      const loading = await this.loadingctrl.create({
         cssClass: 'my-custom-class',
         message: message,
         spinner: "lines-sharp",
         backdropDismiss: true,
         id: 'loader'
      });
      await loading.present();
  }
  async presentToast(message, time = 4000, type="dark")
  {
      const toast = await this.toastCtrl.create({
       message: message,
       position: "bottom",
       color: type,
       duration: time
      });
      toast.present();
   }
}
